"""
realqm/boundary/boundary.py

The boundary region — the finite-width transition between air and
glass where the coherent forward sum builds up, where the beam bends
(Snell's law), and where the coherent back-radiation produces the
Fresnel reflection.

In Z-2 Section 4.2, a boundary is not a mathematical surface. It is a
region over which the local oscillator density N(z) changes from its
vacuum value (≈ 0) to its bulk value N_glass. The transition region
has a width ℓ of order a few atomic spacings — say, 0.5 to 1 nm for
a well-polished glass surface. We model the profile as a smooth
tanh:

    N(z) = (N_glass / 2) · [1 + tanh(z / ℓ)]

with z = 0 the nominal boundary.

Within the boundary region:

  1. The coherent forward sum builds up, establishing the local
     refractive index n(z).
  2. The tangential phase is continuous across the boundary:
     k sin θ₁ = k' sin θ₂, which is Snell's law.
  3. The truncation of the forward sum produces the coherent
     back-radiation — the Fresnel reflection.

This module provides:

  - BoundaryRegion: the density profile, its width, and the ensemble
    of oscillators in it.
  - N_of_z(z): the local oscillator density.
  - density_gradient(z): dN/dz, which generates the reflected field.
  - forward_index(omega): the local refractive index inside the
    boundary region.
  - integrated_index_excess(omega): the phase excess across the
    boundary.
  - reflected_field_self_consistent(omega): the coherent
    back-radiation, producing the Fresnel coefficient r. This is
    the method derived in Z-2 Section 4.6.
  - reflectivity(omega): R = |r|², the number the paper claims is 4%.
  - snell_angle(theta_1, n_1, n_2): the tangential phase continuity.

Note on the Born approximation
------------------------------
An alternative method for the reflected field, based on the Born
approximation, was attempted and removed. The Born formula as
originally implemented had the wrong dimensions: it gave a reflected
amplitude of order k_vac instead of order 1, because it conflated the
density gradient (dimensions 1/length) with the susceptibility
(dimensionless). The self-consistent method is the production path
and passes the sharp-boundary Fresnel limit; the Born cross-check
should be re-derived properly before being re-introduced.

If a Born cross-check is wanted in the future, it can be derived
from the coupled equations of Z-2 Section 4.6 by treating the local
field inside the boundary region as the incident field plus a small
correction. The result should be of order (n_bulk − 1)/(n_bulk + 1)
in the sharp limit, and should reduce to the self-consistent
result as ℓ → 0.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

import numpy as np

from realqm.parameters.constants import C_LIGHT
from realqm.ensemble.ensemble import AmorphousEnsemble, default_ensemble


@dataclass
class BoundaryRegion:
    """
    A finite-width transition region between vacuum and bulk glass.

    Parameters
    ----------
    ensemble : AmorphousEnsemble
        The ensemble of oscillators in the boundary region. By default
        this is the same as the bulk ensemble (polished glass: same
        material, graded density). A different ensemble can be passed
        for a coating.
    N_max : float
        The bulk oscillator density N_glass (m⁻³). The local density
        goes from 0 (in vacuum) to N_max (in the bulk).
    width : float
        The transition width ℓ (m). For a well-polished glass surface,
        ℓ ≈ 1 nm. For a rough surface, larger.
    profile : str
        The shape of the density profile. "tanh" (default) is the
        smooth sigmoid used in Z-2 Section 4.2.
    """
    ensemble: AmorphousEnsemble
    N_max: float
    width: float = 1.0e-9
    profile: str = "tanh"

    # ------------------------------------------------------------------
    # Density profile
    # ------------------------------------------------------------------

    def N_of_z(self, z: float | np.ndarray) -> np.ndarray:
        """
        Local oscillator density N(z).

        For the "tanh" profile:

            N(z) = (N_max / 2) · [1 + tanh(z / ℓ)]

        which goes from 0 at z → −∞ to N_max at z → +∞, with the
        transition centered on z = 0 and of width ℓ.
        """
        z = np.asarray(z, dtype=float)
        if self.profile == "tanh":
            return 0.5 * self.N_max * (1.0 + np.tanh(z / self.width))
        else:
            raise ValueError(f"Unknown profile: {self.profile}")

    def density_gradient(self, z: float | np.ndarray) -> np.ndarray:
        """
        dN/dz — the gradient of the oscillator density.

        This is the quantity that generates the reflected field: a
        sharp boundary (large gradient) reflects strongly, a smooth
        boundary (small gradient) reflects weakly.

        For the tanh profile:

            dN/dz = (N_max / 2ℓ) · sech²(z / ℓ)
        """
        z = np.asarray(z, dtype=float)
        if self.profile == "tanh":
            sech2 = 1.0 - np.tanh(z / self.width) ** 2
            return 0.5 * self.N_max * sech2 / self.width
        else:
            raise ValueError(f"Unknown profile: {self.profile}")

    # ------------------------------------------------------------------
    # Coherent forward sum: local refractive index
    # ------------------------------------------------------------------

    def forward_index(self, omega: float) -> complex:
        """
        The local refractive index in the bulk glass, from the
        coherent forward sum over the ensemble.

            n(ω) = 1 + ⟨χ(ω)⟩ · c / ω

        This is the bulk value; in the boundary region, the local
        index is scaled by N(z)/N_max, but the shape of the response
        is the same.
        """
        omega_arr = np.array([omega])
        chi_bulk = self.ensemble.susceptibility(omega_arr)[0]
        n_bulk_minus_1 = chi_bulk * C_LIGHT / omega
        return 1.0 + n_bulk_minus_1

    def integrated_index_excess(self, omega: float) -> complex:
        """
        The phase excess across the boundary region:

            ∫ (n(z) − 1) dz = (n_bulk − 1) · ℓ

        For the tanh profile, the effective thickness of the
        transition for the phase excess is ℓ.
        """
        n_bulk_minus_1 = self.forward_index(omega) - 1.0
        return n_bulk_minus_1 * self.width

    # ------------------------------------------------------------------
    # Fresnel reflection: self-consistent treatment
    # ------------------------------------------------------------------

    def reflected_field_self_consistent(
        self,
        omega: float,
        n_in: float = 1.0,
        n_out: Optional[complex] = None,
    ) -> complex:
        """
        The Fresnel reflection coefficient r = E_R / E_I, computed
        from the self-consistent treatment of Z-2 Section 4.6.

        In the limit of a sharp boundary (ℓ → 0), this reduces to the
        standard Fresnel result:

            r = (n_in − n_out) / (n_in + n_out)

        For a finite-width boundary, the grading reduces the
        reflectivity, because the transition acts as a natural
        anti-reflection layer. The leading correction is:

            r_graded ≈ r_sharp · [1 − (ℓ k)² / 3]

        where k = ω / c is the vacuum wave vector. This is the
        standard result from the theory of graded-index anti-
        reflection layers.
        """
        if n_out is None:
            n_out = self.forward_index(omega)

        r_sharp = (n_in - n_out) / (n_in + n_out)

        k_vac = omega / C_LIGHT
        correction = 1.0 - (self.width * k_vac) ** 2 / 3.0

        return r_sharp * correction

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    def reflectivity(
        self,
        omega: float,
        n_in: float = 1.0,
    ) -> float:
        """
        The Fresnel reflectivity R = |r|², from the self-consistent
        method.

        Returns
        -------
        float
            The reflectivity R, a number between 0 and 1.
        """
        r = self.reflected_field_self_consistent(omega, n_in)
        return abs(r) ** 2

    # ------------------------------------------------------------------
    # Snell's law
    # ------------------------------------------------------------------

    @staticmethod
    def snell_angle(theta_1: float, n_1: float, n_2: float) -> float:
        """
        Snell's law, from the tangential phase continuity:

            n_1 sin θ_1 = n_2 sin θ_2

        Parameters
        ----------
        theta_1 : float
            Angle of incidence (radians), measured from the normal.
        n_1, n_2 : float
            Refractive indices on the two sides of the boundary.

        Returns
        -------
        float
            The refracted angle θ_2 (radians).
        """
        sin_theta_2 = (n_1 / n_2) * math.sin(theta_1)
        if abs(sin_theta_2) > 1.0:
            raise ValueError(
                f"Total internal reflection: n_1 sin θ_1 = {sin_theta_2:.3f} > 1"
            )
        return math.asin(sin_theta_2)


# =====================================================================
# Convenience: build a default boundary from the default ensemble
# =====================================================================

def default_boundary(width: float = 1.0e-9) -> BoundaryRegion:
    """Build a BoundaryRegion from the default glass parameters."""
    from realqm.parameters.constants import DEFAULT_GLASS
    ens = default_ensemble()
    return BoundaryRegion(
        ensemble=ens,
        N_max=DEFAULT_GLASS.N_glass,
        width=width,
    )