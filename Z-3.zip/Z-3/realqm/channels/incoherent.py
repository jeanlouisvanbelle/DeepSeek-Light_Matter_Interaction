"""
realqm/channels/incoherent.py

Channel 3 — incoherent side-scattering.

In Z-2 Section 5, the third channel of the RealQM picture is the
incoherent scattering from frozen-in density fluctuations in the
glass. The beam is visible inside the slab because a small fraction
of the photons are scattered sideways, in all directions, by
sub-wavelength density fluctuations. These fluctuations are frozen
in by the rapid cooling that forms glass, and their variance is set
by the fictive temperature T_f.

Assumption: no absorption
-------------------------
The glass does not absorb the photon energy as heat. The extinction
coefficient μ is a *scattering* coefficient, not an absorption
coefficient: the intensity removed from the forward beam is
redirected into the side-scattered channel, not lost from the
system. This is an excellent approximation for optical glass at
visible wavelengths, where the absorption coefficient is many
orders of magnitude smaller than the scattering coefficient. As a
consequence, the energy ledger closes with three channels and no
fourth "absorbed" channel.

This module provides:

  - IncoherentChannel: the extinction coefficient μ(ω), the
    Rayleigh cross-section, and the Beer-Lambert attenuation.
  - extinction_coefficient(omega): μ(ω), with the Rayleigh λ⁻⁴
    scaling.
  - beer_lambert(I_0, L): the attenuated forward intensity.
  - side_scattered_fraction(L): the fraction scattered sideways.

The Rayleigh λ⁻⁴ scaling
------------------------
The scattering cross-section of a single driven oscillator scales as
ω⁴, hence λ⁻⁴. This is the same ω² acceleration factor that produced
the coherent forward channel, viewed in the transverse direction.
The extinction coefficient therefore inherits the λ⁻⁴ law:

    μ(ω) ∝ ⟨N⟩ · (⟨(δN)²⟩ / ⟨N⟩²) · λ⁻⁴

The overall prefactor depends on the full Rayleigh cross-section
(angular integration, polarization factors, absolute normalization),
which we defer to a future paper. The tests check the *scaling*,
not the absolute value.

Units
-----
Extinction coefficient μ: m⁻¹
Path length L: m
Intensity I: arbitrary (ratios are what matter)
Wavelength λ: m
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from realqm.parameters.constants import C_LIGHT, K_B, ScatteringMaterial


# Bulk modulus of fused silica (Pa), as a default.
K_GLASS: float = 3.7e10

# Reference wavelength for the extinction coefficient (m).
LAMBDA_REF: float = 550e-9


@dataclass
class IncoherentChannel:
    """
    The incoherent side-scattering channel of the RealQM model.

    Parameters
    ----------
    N_glass : float
        Mean oscillator density (m⁻³).
    T_fictive : float
        Fictive temperature (K).
    K_bulk : float
        Bulk modulus (Pa).
    mu_ref : float
        Reference extinction coefficient (m⁻¹) at lambda_ref.
    lambda_ref : float
        Reference wavelength (m). Default 550 nm.
    """
    N_glass: float
    T_fictive: float = 800.0
    K_bulk: float = K_GLASS
    mu_ref: float = 0.5
    lambda_ref: float = LAMBDA_REF

    # ------------------------------------------------------------------
    # Alternative constructor
    # ------------------------------------------------------------------

    @classmethod
    def from_material(cls, material: ScatteringMaterial) -> "IncoherentChannel":
        """
        Build an IncoherentChannel from a named ScatteringMaterial.
        """
        return cls(
            N_glass=material.N_glass,
            T_fictive=material.T_fictive,
            K_bulk=material.K_bulk,
            mu_ref=material.mu_ref,
            lambda_ref=material.lambda_ref,
        )

    # ------------------------------------------------------------------
    # Density fluctuations
    # ------------------------------------------------------------------

    def fractional_variance(self) -> float:
        """
        The fractional variance of the density fluctuations:

            ⟨(δN)²⟩ / ⟨N⟩² ≈ k_B T_f ⟨N⟩ / K
        """
        return K_B * self.T_fictive * self.N_glass / self.K_bulk

    # ------------------------------------------------------------------
    # Rayleigh scaling
    # ------------------------------------------------------------------

    def rayleigh_factor(self, omega: float) -> float:
        """
        The Rayleigh scaling factor (λ_ref / λ)⁴ = (ω / ω_ref)⁴.
        """
        lambda_ = 2.0 * math.pi * C_LIGHT / omega
        return (self.lambda_ref / lambda_) ** 4

    # ------------------------------------------------------------------
    # Extinction coefficient
    # ------------------------------------------------------------------

    def extinction_coefficient(self, omega: float) -> float:
        """
        The extinction coefficient μ(ω) at frequency ω.

            μ(ω) = μ_ref · (λ_ref / λ)⁴
        """
        return self.mu_ref * self.rayleigh_factor(omega)

    def extinction_at_wavelength(self, lambda_: float) -> float:
        """
        The extinction coefficient at a given wavelength (m).
        """
        omega = 2.0 * math.pi * C_LIGHT / lambda_
        return self.extinction_coefficient(omega)

    # ------------------------------------------------------------------
    # Beer-Lambert
    # ------------------------------------------------------------------

    def beer_lambert(self, I_0: float, L: float, omega: float) -> float:
        """
        The Beer-Lambert law: I(L) = I_0 · exp(−μ L).
        """
        mu = self.extinction_coefficient(omega)
        return I_0 * math.exp(-mu * L)

    def side_scattered_fraction(self, L: float, omega: float) -> float:
        """
        The fraction of the incident intensity that has been scattered
        sideways over a path length L:

            f_side = 1 − exp(−μ L)
        """
        mu = self.extinction_coefficient(omega)
        return 1.0 - math.exp(-mu * L)


# =====================================================================
# Convenience: build a default incoherent channel
# =====================================================================

def default_incoherent_channel() -> IncoherentChannel:
    """Build an IncoherentChannel with default glass parameters."""
    from realqm.parameters.constants import FUSED_SILICA
    return IncoherentChannel.from_material(FUSED_SILICA)