"""
realqm/slab/slab.py

The full glass slab — the composition of the entry boundary, the bulk,
and the exit boundary. This is the module that produces the paper's
central numbers: the 4% Fresnel reflection, the visible track, the
two bends, and the three-channel energy ledger.

In Z-2 Sections 6.1–6.6, the slab is assembled from:

  - Entry boundary: the beam bends from θ₁ to θ₂ (Snell's law), and
    a fraction R of the incident intensity is reflected back.
  - Bulk: the beam propagates at θ₂ with phase velocity c/n, and is
    attenuated by the incoherent channel at rate μ.
  - Exit boundary: the beam bends back from θ₂ to θ₁, and a second
    Fresnel reflection occurs (this is the internal reflection that
    feeds the Fabry-Perot sum, a higher-order correction).

The three-channel energy ledger (Z-2 Section 5.7) is:

    I₀ = R I₀                                (Channel 2: Fresnel)
       + T² I₀ e^{−μ L / cos θ₂}             (Channel 1 + Ch. 3: forward)
       + T² I₀ (1 − e^{−μ L / cos θ₂})       (Channel 3: side-scattered)
       + O(R²)                               (multiple reflections)

This module provides:

  - Slab: the geometry (thickness L, entry boundary, exit boundary,
    bulk ensemble) and the methods to compute the ledger terms.
  - internal_angle(theta_1): the refracted angle θ₂ inside the slab.
  - path_length(theta_1): the internal path length L / cos θ₂.
  - fresnel_coefficient(omega): the entry-face reflectivity R.
  - ledger(omega, theta_1): the three-channel energy ledger.
  - lateral_displacement(theta_1): the displacement of the emergent
    beam, parallel to the incident beam.
  - airy_transmission(omega, L): the Fabry-Perot transmission for a
    plane-parallel slab, with the multiple-reflection sum.

The Fabry-Perot fringes have a period of λ/(2n) ≈ 183 nm for visible
light in glass, which is far below the resolution of any practical
measurement. For an uncoated slab (R = 0.04), the average over many
fringes coincides with the single-pass value T² to within 0.2%.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

import numpy as np

from realqm.parameters.constants import (
    C_LIGHT,
    DEFAULT_GLASS,
)
from realqm.ensemble.ensemble import AmorphousEnsemble, default_ensemble
from realqm.boundary.boundary import BoundaryRegion, default_boundary
from realqm.channels.incoherent import IncoherentChannel, default_incoherent_channel


@dataclass
class Slab:
    """
    A plane-parallel glass slab.

    Parameters
    ----------
    thickness : float
        The slab thickness L (m).
    entry : BoundaryRegion
        The entry boundary region.
    exit : BoundaryRegion
        The exit boundary region.
    bulk : AmorphousEnsemble
        The bulk ensemble (the same as the boundary ensembles by
        default, but could be different for a coated slab).
    incoherent : IncoherentChannel
        The incoherent channel, which provides the extinction
        coefficient μ(ω).
    """
    thickness: float
    entry: BoundaryRegion
    exit: BoundaryRegion
    bulk: AmorphousEnsemble
    incoherent: IncoherentChannel

    # ------------------------------------------------------------------
    # Geometry: Snell's law and path length
    # ------------------------------------------------------------------

    def internal_angle(self, theta_1: float, omega: float) -> float:
        """
        The refracted angle θ₂ inside the slab, from Snell's law.

        Uses the bulk refractive index at frequency ω.
        """
        n_bulk = self.bulk_refractive_index(omega).real
        return self.entry.snell_angle(theta_1, 1.0, n_bulk)

    def path_length(self, theta_1: float, omega: float) -> float:
        """
        The path length through the slab for a beam entering at θ₁:

            L_path = L / cos θ₂

        where θ₂ is the internal angle from Snell's law.
        """
        theta_2 = self.internal_angle(theta_1, omega)
        return self.thickness / math.cos(theta_2)

    def lateral_displacement(self, theta_1: float, omega: float) -> float:
        """
        The lateral displacement of the emergent beam:

            d = L · sin(θ₁ − θ₂) / cos θ₂

        For a plane-parallel slab, the emergent beam is parallel to
        the incident beam, displaced laterally by d.
        """
        theta_2 = self.internal_angle(theta_1, omega)
        return self.thickness * math.sin(theta_1 - theta_2) / math.cos(theta_2)

    # ------------------------------------------------------------------
    # Refractive index and Fresnel coefficients
    # ------------------------------------------------------------------

    def bulk_refractive_index(self, omega: float) -> complex:
        """
        The bulk refractive index at frequency ω, from the ensemble-
        averaged susceptibility.
        """
        omega_arr = np.array([omega])
        chi = self.bulk.susceptibility(omega_arr)[0]
        return 1.0 + chi * C_LIGHT / omega

    def fresnel_coefficient(self, omega: float) -> complex:
        """
        The Fresnel reflection coefficient r at the entry face
        (air → glass), for normal incidence.

            r = (n_air − n_glass) / (n_air + n_glass)

        This is the self-consistent boundary result, including the
        reduction from the finite boundary width.
        """
        return self.entry.reflected_field_self_consistent(omega, n_in=1.0)

    def fresnel_reflectivity(self, omega: float) -> float:
        """R = |r|², the entry-face reflectivity."""
        return abs(self.fresnel_coefficient(omega)) ** 2

    def fresnel_transmissivity(self, omega: float) -> float:
        """T = 1 − R, the entry-face transmissivity (for a lossless
        boundary)."""
        return 1.0 - self.fresnel_reflectivity(omega)

    # ------------------------------------------------------------------
    # Three-channel energy ledger
    # ------------------------------------------------------------------

    def ledger(
        self,
        omega: float,
        theta_1: float = 0.0,
        I_0: float = 1.0,
    ) -> dict:
        """
        The full energy ledger for the slab, including the multiple-
        reflection correction.

        For a plane-parallel slab, the energy balance including all
        multiple internal reflections is:

            I₀ = R_total I₀ + T_total I₀

        where

            R_total = R + T² R / (1 − R²)
            T_total = T² / (1 − R²)

        are the total reflected and transmitted fractions, summing
        all the multiple internal bounces.

        The three-channel decomposition of the ledger is:

          - fresnel:       R I₀            (first-surface reflection)
          - multiple:      (R_total − R) I₀ (extra light from internal bounces)
          - forward:       T_total I₀ e^{−μ L_path}
          - side:          T_total I₀ (1 − e^{−μ L_path})

        The sum is R_total I₀ + T_total I₀ = I₀ exactly.

        Returns
        -------
        dict
            Keys: I_0, R, T, R_total, T_total, mu, L_path, fresnel,
            multiple, forward, side, sum, residual.
        """
        R = self.fresnel_reflectivity(omega)
        T = 1.0 - R
        mu = self.incoherent.extinction_coefficient(omega)
        L_path = self.path_length(theta_1, omega)

        # Total reflected and transmitted fractions, summing the
        # geometric series of multiple internal reflections.
        # R_total = R + T² R / (1 − R²)
        # T_total = T² / (1 − R²)
        denom = 1.0 - R * R
        T_total = T * T / denom
        R_total = R + T * T * R / denom

        # The three-channel decomposition
        fresnel_term = R * I_0                              # first-surface reflection
        multiple_term = (R_total - R) * I_0                 # extra from internal bounces
        transmission_factor = math.exp(-mu * L_path)
        forward_term = T_total * I_0 * transmission_factor  # forward transmission
        side_term = T_total * I_0 * (1.0 - transmission_factor)  # side-scattered

        total = fresnel_term + multiple_term + forward_term + side_term
        residual = total - I_0

        return {
            "I_0": I_0,
            "R": R,
            "T": T,
            "R_total": R_total,
            "T_total": T_total,
            "mu": mu,
            "L_path": L_path,
            "fresnel": fresnel_term,
            "multiple": multiple_term,
            "forward": forward_term,
            "side": side_term,
            "sum": total,
            "residual": residual,
        }


    # ------------------------------------------------------------------
    # Fabry-Perot (Airy) transmission
    # ------------------------------------------------------------------

    def airy_transmission(
        self,
        omega: float,
        theta_1: float = 0.0,
        include_absorption: bool = False,
    ) -> float:
        """
        The Fabry-Perot (Airy) transmission of the slab, including
        the multiple-reflection sum.

        For a plane-parallel slab of thickness L, refractive index n,
        and absorption coefficient μ, the Airy formula is:

            T_total = T² e^{−μ L_path} / [1 − R² e^{−2μ L_path} e^{2iδ}]

        with δ = 2π n L_path / λ the round-trip phase. For the lossless
        case (μ = 0):

            T_total = T² / [(1 − R)² + 4R sin²(δ/2)]

        Parameters
        ----------
        omega : float
            Frequency (rad/s).
        theta_1 : float
            Angle of incidence (radians).
        include_absorption : bool
            If True, include the μ-dependent terms. If False (default),
            use the lossless form.

        Returns
        -------
        float
            The transmitted intensity fraction.
        """
        R = self.fresnel_reflectivity(omega)
        T = 1.0 - R
        n = self.bulk_refractive_index(omega).real
        L_path = self.path_length(theta_1, omega)

        # Round-trip phase
        lambda_ = 2.0 * math.pi * C_LIGHT / omega
        delta = 2.0 * math.pi * n * L_path / lambda_

        if include_absorption:
            mu = self.incoherent.extinction_coefficient(omega)
            absorption_factor = math.exp(-mu * L_path)
            denominator = 1.0 - 2.0 * R * absorption_factor * math.cos(2.0 * delta) \
                + R**2 * absorption_factor**2
            return T**2 * absorption_factor / denominator
        else:
            denominator = (1.0 - R) ** 2 + 4.0 * R * math.sin(delta / 2.0) ** 2
            return T**2 / denominator

    def airy_fringe_extrema(self, omega: float) -> tuple[float, float]:
        """
        The extrema of the Airy transmission for a lossless slab:

            T_min = T² / (1 + R)²
            T_max = T² / (1 − R)²

        For uncoated glass (R = 0.04, T = 0.96):

            T_min ≈ 0.852
            T_max ≈ 1.000

        a fringe amplitude of roughly 7%.
        """
        R = self.fresnel_reflectivity(omega)
        T = 1.0 - R
        return (T**2 / (1.0 + R) ** 2, T**2 / (1.0 - R) ** 2)

    def airy_average(self, omega: float) -> float:
        """
        The average of the Airy transmission over many fringes:

            ⟨T_total⟩ = T² / (1 − R²)

        For uncoated glass, this is approximately 0.923, which
        coincides with the single-pass value T² = 0.9216 to within
        0.2%.
        """
        R = self.fresnel_reflectivity(omega)
        T = 1.0 - R
        return T**2 / (1.0 - R**2)


# =====================================================================
# Convenience: build a default slab
# =====================================================================

def default_slab(thickness: float = 1.0e-2, boundary_width: float = 1.0e-9) -> Slab:
    """
    Build a Slab from the default glass parameters.

    Parameters
    ----------
    thickness : float
        Slab thickness (m). Default 1 cm.
    boundary_width : float
        Boundary transition width (m). Default 1 nm.
    """
    ens = default_ensemble()
    return Slab(
        thickness=thickness,
        entry=BoundaryRegion(ensemble=ens, N_max=DEFAULT_GLASS.N_glass,
                             width=boundary_width),
        exit=BoundaryRegion(ensemble=ens, N_max=DEFAULT_GLASS.N_glass,
                            width=boundary_width),
        bulk=ens,
        incoherent=default_incoherent_channel(),
    )