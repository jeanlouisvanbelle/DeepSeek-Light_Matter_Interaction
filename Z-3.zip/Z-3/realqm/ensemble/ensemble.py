"""
realqm/ensemble/ensemble.py

The amorphous ensemble — the Gaussian distribution of resonance
frequencies that turns a single oscillator into a glass.

In Z-2 Section 2.3, glass is described as an amorphous network of
SiO₂ tetrahedra, with local bond lengths and bond angles that vary
from site to site. The consequence is that the local resonance
frequencies ω₀ are distributed, with mean ω̄₀ and width σ_ω₀.
By the central limit theorem, the distribution is Gaussian:

    P(ω₀) = (1 / √(2π) σ_ω₀) exp[ −(ω₀ − ω̄₀)² / (2 σ_ω₀²) ]

The distribution is truncated at ω₀ = 0: there are no negative
resonance frequencies. For the default glass (ω̄₀/σ_ω₀ ≈ 6.7),
the truncation removes only a negligible fraction of the weight
(~2e-10), but it removes a spurious resonance at ω₀ = −ω that
would otherwise contaminate the ensemble average near the physical
resonance.

The ensemble average of any function f(ω, ω₀) is

    ⟨f(ω)⟩ = ∫₀^∞ f(ω, ω₀) P(ω₀) dω₀

This module provides:

  - AmorphousEnsemble: the distribution, its mean and width, and the
    ensemble average of a function of ω₀.
  - average: vectorised production path (fine uniform grid).
  - average_scalar: scalar cross-check (scipy.integrate.quad with a
    break point at ω₀ = ω).
  - average_fine: fine-grid reference (10⁶ points, trapezoidal).
  - susceptibility: the ensemble-averaged susceptibility ⟨χ(ω)⟩.
  - bracket: the ensemble-averaged bracket ⟨B(ω)⟩.

The production path uses a dense uniform grid. The grid range and
spacing are derived from the physical widths of the problem:

    range   = [max(0, ω̄₀ − n_sigma_grid·σ_ω₀), ω̄₀ + n_sigma_grid·σ_ω₀]
    spacing = γ / n_per_gamma

with n_sigma_grid = 8 and n_per_gamma = 50 by default. The trapezoidal
error on a Lorentzian of width γ with spacing γ/n is of order (1/n)²,
so n_per_gamma = 50 gives ~1e-3 accuracy, n_per_gamma = 100 gives
~1e-4, and n_per_gamma = 10 gives only ~1e-2.

The scalar quad path must be given a break point at ω₀ = ω, because
without it the adaptive integrator can miss the sharp resonance.
This was verified by comparing against an independent fine-grid
trapezoidal reference (see average_fine and test_ensemble.py).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable

import numpy as np


@dataclass
class AmorphousEnsemble:
    """
    An amorphous ensemble of driven oscillators.

    Parameters
    ----------
    omega_0_bar : float
        Mean resonance frequency (rad/s).
    sigma_omega_0 : float
        Inhomogeneous width (rad/s).
    gamma : float
        Homogeneous damping rate (rad/s).
    N_glass : float
        Number density of oscillators (m⁻³).

    Grid parameters
    ---------------
    n_sigma_grid : float
        Half-range of the integration grid in units of σ_ω₀.
        Default 8.
    n_per_gamma : float
        Number of grid points per unit of γ. Default 50.
    """
    omega_0_bar: float
    sigma_omega_0: float
    gamma: float
    N_glass: float
    n_sigma_grid: float = 8.0
    n_per_gamma: float = 50.0

    # Cached grid, built lazily on first use.
    _grid: np.ndarray = field(default=None, init=False, repr=False)

    # ------------------------------------------------------------------
    # Distribution and its moments
    # ------------------------------------------------------------------

    def P(self, omega_0) -> np.ndarray:
        """
        Gaussian distribution P(ω₀) with mean ω̄₀ and width σ_ω₀,
        truncated at ω₀ = 0.

        There are no negative resonance frequencies, so P is set to
        zero for ω₀ ≤ 0. For the default glass (ω̄₀/σ_ω₀ ≈ 6.7), the
        truncation removes a negligible fraction of the weight, but
        it removes a spurious resonance at ω₀ = −ω.
        """
        omega_0 = np.asarray(omega_0, dtype=float)
        norm = 1.0 / (math.sqrt(2.0 * math.pi) * self.sigma_omega_0)
        exponent = -(omega_0 - self.omega_0_bar) ** 2 / (2.0 * self.sigma_omega_0**2)
        P = norm * np.exp(exponent)
        return np.where(omega_0 > 0.0, P, 0.0)

    def fractional_disorder(self) -> float:
        """σ_ω₀ / ω̄₀ — the dimensionless disorder parameter."""
        return self.sigma_omega_0 / self.omega_0_bar

    def mean_inverse_square(self) -> float:
        """
        The ensemble average ⟨1/ω₀²⟩.

        For a Gaussian truncated at 0, the leading correction to
        1/ω̄₀² is 3(σ_ω₀/ω̄₀)²:

            ⟨1/ω₀²⟩ ≈ (1/ω̄₀²) · (1 + 3 σ_ω₀²/ω̄₀²)

        For our default glass (σ/ω̄ = 0.15), this is a ~7% correction.
        """
        s = self.sigma_omega_0 / self.omega_0_bar
        return (1.0 / self.omega_0_bar**2) * (1.0 + 3.0 * s**2)

    # ------------------------------------------------------------------
    # The integration grid (derived from physics)
    # ------------------------------------------------------------------

    def _build_grid(self) -> np.ndarray:
        """
        Build the uniform integration grid.

        The grid runs from max(0, ω̄₀ − n_sigma_grid·σ_ω₀) to
        ω̄₀ + n_sigma_grid·σ_ω₀. Truncating at 0 removes the spurious
        negative-frequency resonance.

        The spacing is γ / n_per_gamma, which resolves the resonance
        wherever it falls under the Gaussian.
        """
        lower = max(0.0, self.omega_0_bar - self.n_sigma_grid * self.sigma_omega_0)
        upper = self.omega_0_bar + self.n_sigma_grid * self.sigma_omega_0
        spacing = self.gamma / self.n_per_gamma
        n_points = int((upper - lower) / spacing) + 1

        max_points = 500_000
        if n_points > max_points:
            import warnings
            warnings.warn(
                f"Integration grid would have {n_points} points "
                f"(σ_ω₀/γ = {self.sigma_omega_0/self.gamma:.1f}); "
                f"capping at {max_points}. "
                f"The resonance may be under-resolved.",
                RuntimeWarning,
            )
            n_points = max_points

        return np.linspace(lower, upper, n_points)

    def grid(self) -> np.ndarray:
        """The integration grid, built once and cached."""
        if self._grid is None:
            self._grid = self._build_grid()
        return self._grid

    # ------------------------------------------------------------------
    # Ensemble average: vectorised production path
    # ------------------------------------------------------------------

    def average(
        self,
        omega_grid: np.ndarray,
        func: Callable[[np.ndarray, np.ndarray], np.ndarray],
    ) -> np.ndarray:
        """
        Ensemble average ⟨f(ω, ω₀)⟩ on a grid of ω, vectorised.

        Uses a dense uniform grid over ω₀, with spacing derived from
        the resonance width γ, and range derived from the Gaussian
        width σ_ω₀. The quadrature is a Riemann sum with the Gaussian
        weight.

        Parameters
        ----------
        omega_grid : np.ndarray
            Frequencies at which to evaluate the average.
        func : callable
            f(omega, omega_0) — the function to average over ω₀.
            Must accept NumPy arrays and return a NumPy array of the
            same shape.

        Returns
        -------
        np.ndarray
            ⟨f(ω)⟩ on the same grid as omega_grid.
        """
        omega_grid = np.asarray(omega_grid, dtype=float)
        omega_0 = self.grid()
        P = self.P(omega_0)

        # Build the (n_omega, n_omega_0) grid and evaluate the integrand.
        W, W0 = np.meshgrid(omega_grid, omega_0, indexing="ij")
        values = func(W, W0)

        # Trapezoidal sum with the Gaussian weight.
        return np.trapezoid(values * P[None, :], omega_0, axis=1)

    # ------------------------------------------------------------------
    # Ensemble average: scalar cross-check
    # ------------------------------------------------------------------

    def average_scalar(
        self,
        omega: float,
        func: Callable[[float, float], complex],
        n_sigma: float = 10.0,
    ) -> complex:
        """
        Ensemble average ⟨f(ω, ω₀)⟩ at a single ω, using
        scipy.integrate.quad with a break point at ω₀ = ω.

        The break point is essential: without it, the adaptive
        integrator can miss the sharp resonance at ω₀ = ω and
        return a wrong answer. With it, quad is accurate.

        The integration range is [max(0, ω̄₀ − n_sigma σ_ω₀),
        ω̄₀ + n_sigma σ_ω₀].
        """
        from scipy.integrate import quad

        a = max(0.0, self.omega_0_bar - n_sigma * self.sigma_omega_0)
        b = self.omega_0_bar + n_sigma * self.sigma_omega_0

        def integrand_real(w0: float) -> float:
            return (func(omega, w0) * self.P(w0)).real

        def integrand_imag(w0: float) -> float:
            return (func(omega, w0) * self.P(w0)).imag

        real = quad(integrand_real, a, b, points=[omega], limit=400,
                    epsabs=1e-14, epsrel=1e-12)[0]
        imag = quad(integrand_imag, a, b, points=[omega], limit=400,
                    epsabs=1e-14, epsrel=1e-12)[0]
        return real + 1j * imag

    # ------------------------------------------------------------------
    # Ensemble average: fine-grid reference
    # ------------------------------------------------------------------

    def average_fine(
        self,
        omega: float,
        func: Callable[[float, float], complex],
        n_points: int = 1_000_000,
    ) -> complex:
        """
        Ensemble average ⟨f(ω, ω₀)⟩ at a single ω, computed on a
        very fine uniform grid, as a robust independent reference.

        This method trades speed for accuracy: it uses n_points
        (default 10⁶) uniformly spaced over the full range
        [max(0, ω̄₀ − n_sigma_grid σ_ω₀), ω̄₀ + n_sigma_grid σ_ω₀].
        It is not fooled by sharp resonances, because the grid is
        fine enough to resolve them by many points.

        It is used in the test suite as the ground-truth reference
        against which the vectorised production path is compared.
        """
        lower = max(0.0, self.omega_0_bar - self.n_sigma_grid * self.sigma_omega_0)
        upper = self.omega_0_bar + self.n_sigma_grid * self.sigma_omega_0
        w0 = np.linspace(lower, upper, n_points)
        P = self.P(w0)
        values = func(omega, w0) * P
        return np.trapezoid(values, w0)

    # ------------------------------------------------------------------
    # Ensemble-averaged quantities
    # ------------------------------------------------------------------

    def bracket(self, omega_grid: np.ndarray) -> np.ndarray:
        """
        Ensemble-averaged bracket ⟨B(ω)⟩ = ⟨ω² / D(ω)⟩ on a grid of ω.
        """
        omega_grid = np.asarray(omega_grid, dtype=float)

        def integrand(W: np.ndarray, W0: np.ndarray) -> np.ndarray:
            D = (W0**2 - W**2) + 1j * self.gamma * W
            return W**2 / D

        return self.average(omega_grid, integrand)

    def susceptibility(self, omega_grid: np.ndarray) -> np.ndarray:
        """
        Ensemble-averaged susceptibility ⟨χ(ω)⟩ on a grid of ω.
        """
        from realqm.parameters.constants import (
            EPSILON_0, C_LIGHT, Q_E, M_E,
        )
        omega_grid = np.asarray(omega_grid, dtype=float)
        B = self.bracket(omega_grid)
        prefactor = self.N_glass * Q_E**2 / (
            2.0 * EPSILON_0 * M_E * C_LIGHT * omega_grid
        )
        return prefactor * B


# =====================================================================
# Convenience: build a default ensemble from GlassParameters
# =====================================================================

def default_ensemble() -> AmorphousEnsemble:
    """Build an AmorphousEnsemble from the default glass parameters."""
    from realqm.parameters.constants import DEFAULT_GLASS
    return AmorphousEnsemble(
        omega_0_bar=DEFAULT_GLASS.omega_0_bar,
        sigma_omega_0=DEFAULT_GLASS.sigma_omega_0,
        gamma=DEFAULT_GLASS.gamma,
        N_glass=DEFAULT_GLASS.N_glass,
    )