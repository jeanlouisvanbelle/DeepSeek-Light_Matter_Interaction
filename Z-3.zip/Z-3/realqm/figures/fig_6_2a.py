"""
realqm/figures/fig_6_2a.py

Figure 6.2a of the Z-2 paper: the Airy transmission of an uncoated
glass slab.

The blue curve is the full multiple-reflection sum T_total(L),
computed from the Airy formula. The red dashed line is the
single-pass value T², which the Airy oscillation averages to.

The Airy fringes have a period of λ/(2n), where n is the bulk
refractive index at the photon's frequency. For a green photon
(551 nm) in glass with n ≈ 1.44, the period is about 191 nm.
For a 1 cm slab, the number of fringes is huge (~5 × 10⁴), and
any practical measurement averages over many of them, so what
we observe is the average, T² / (1 − R²), which coincides with
T² to within 0.2% for uncoated glass.

This figure shows what is happening on the scale of individual
fringes: the Airy curve oscillates between T² / (1+R)² and
T² / (1−R)² as the thickness varies.

Run from the Z-3 directory:
    python -m realqm.figures.fig_6_2a

Outputs:
    realqm/figures/output/fig_6_2a.png
    realqm/figures/output/fig_6_2a.log
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from realqm.parameters.constants import GREEN_PHOTON
from realqm.slab.slab import default_slab


# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

# Thickness range: cover about 6 fringes.
L_START_M = 1.0e-5              # 10 μm
L_END_M   = 1.0e-5 + 1.2e-6     # +1.2 μm, about 6 fringes

N_POINTS = 800


# ---------------------------------------------------------------------
# Compute the Airy curve
# ---------------------------------------------------------------------

def compute_curve() -> dict:
    """
    Compute the Airy transmission as a function of slab thickness.
    """
    omega = GREEN_PHOTON.omega
    slab = default_slab(thickness=1.0)

    # Bulk index and Fresnel reflectivity
    n_bulk = slab.bulk_refractive_index(omega).real
    R = slab.fresnel_reflectivity(omega)
    T = 1.0 - R

    # Fringe period
    lambda_ = GREEN_PHOTON.wavelength
    fringe_period = lambda_ / (2.0 * n_bulk)

    # Thickness grid
    L_m = np.linspace(L_START_M, L_END_M, N_POINTS)
    T_airy = np.zeros_like(L_m)
    for i, L in enumerate(L_m):
        slab_L = default_slab(thickness=L)
        T_airy[i] = slab_L.airy_transmission(omega)

    # The single-pass value
    T_single = T * T

    # The extrema of the Airy oscillation
    T_min = T * T / (1.0 + R) ** 2
    T_max = T * T / (1.0 - R) ** 2

    # The average over many fringes
    T_avg = T * T / (1.0 - R * R)

    return {
        "L_um": L_m * 1e6,
        "T_airy": T_airy,
        "T_single": T_single,
        "T_min": T_min,
        "T_max": T_max,
        "T_avg": T_avg,
        "R": R,
        "T": T,
        "n_bulk": n_bulk,
        "fringe_period_nm": fringe_period * 1e9,
    }


# ---------------------------------------------------------------------
# Plot
# ---------------------------------------------------------------------

def make_figure(data: dict, output_path: Path) -> None:
    """Draw the figure and save it."""
    fig, ax = plt.subplots(figsize=(9.5, 5.2))

    ax.plot(data["L_um"], data["T_airy"],
            color="#1f4e79", linewidth=1.4,
            label="Airy (full multiple-reflection sum)")
    ax.axhline(data["T_single"],
               color="#c0392b", linewidth=1.4, linestyle="--",
               label="Simple T² (no multiple reflections)")

    ax.set_xlabel("Slab thickness L (μm)")
    ax.set_ylabel("Transmitted intensity (fraction)")
    ax.set_title(
        f"Airy transmission for uncoated glass "
        f"(R = {data['R']:.3f}, "
        f"fringe period ≈ {data['fringe_period_nm']:.0f} nm)"
    )
    ax.legend(loc="center right", fontsize=9, frameon=True)
    ax.grid(True, linewidth=0.3, alpha=0.5)

    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


# ---------------------------------------------------------------------
# Log
# ---------------------------------------------------------------------

def write_log(data: dict, log_path: Path) -> None:
    """Write a numerical log with the key values from the figure."""
    lines = []
    lines.append("Figure 6.2a — Airy transmission, uncoated glass")
    lines.append("=" * 60)
    lines.append("")
    lines.append(f"Photon: {GREEN_PHOTON.energy_eV:.2f} eV "
                 f"({GREEN_PHOTON.wavelength*1e9:.0f} nm)")
    lines.append("")
    lines.append(f"Bulk refractive index at this photon: n = {data['n_bulk']:.6f}")
    lines.append(f"Fresnel reflectivity: R = {data['R']:.6f}")
    lines.append(f"Fresnel transmissivity: T = {data['T']:.6f}")
    lines.append(f"Fringe period: λ / (2n) = {data['fringe_period_nm']:.2f} nm")
    lines.append("")
    lines.append(f"Airy extrema:")
    lines.append(f"  T_min = T² / (1+R)² = {data['T_min']:.6f}")
    lines.append(f"  T_max = T² / (1−R)² = {data['T_max']:.6f}")
    lines.append(f"  fringe amplitude = {data['T_max'] - data['T_min']:.6f}")
    lines.append("")
    lines.append(f"Single-pass value: T² = {data['T_single']:.6f}")
    lines.append(f"Average over many fringes: T² / (1−R²) = {data['T_avg']:.6f}")
    lines.append(f"Difference: "
                 f"{abs(data['T_avg'] - data['T_single']) / data['T_single'] * 100:.3f}%")
    lines.append("")
    lines.append("Notes:")
    lines.append("- The Airy curve oscillates between T_min and T_max as")
    lines.append("  the thickness varies.")
    lines.append("- The single-pass value T² is the average over many")
    lines.append("  fringes, and it agrees with the Airy average to within")
    lines.append("  a fraction of a percent.")
    lines.append("- For a 1 cm slab, the number of fringes is enormous")
    lines.append("  (~5 × 10⁴), so any practical measurement averages over")
    lines.append("  many of them and observes the single-pass value.")

    log_path.write_text("\n".join(lines), encoding="utf-8")


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------

def main() -> None:
    output_dir = Path(__file__).parent / "output"
    output_dir.mkdir(exist_ok=True)

    data = compute_curve()
    make_figure(data, output_dir / "fig_6_2a.png")
    write_log(data, output_dir / "fig_6_2a.log")

    print(f"Wrote {output_dir / 'fig_6_2a.png'}")
    print(f"Wrote {output_dir / 'fig_6_2a.log'}")


if __name__ == "__main__":
    main()