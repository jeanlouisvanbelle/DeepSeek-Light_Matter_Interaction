"""
realqm/figures/fig_3_2.py

Figure 3.2 of the Z-2 paper: the refractive index of the
amorphous lattice.

Two panels, for the glassy case (σ_ω₀/ω̄₀ = 0.15):
  - Top:    Re n(ω) vs. ω/ω̄₀, with the Sellmeier low-frequency
            limit as a horizontal dotted line.
  - Bottom: Im n(ω) vs. ω/ω̄₀.

The figure illustrates Z-2 Section 3.5: the real part of n
approaches the Sellmeier limit from above at low frequency,
exhibits anomalous dispersion near resonance, and approaches
unity from below at high frequency. The imaginary part has a
peak at the resonance.

Run from the Z-3/ directory:
    python -m realqm.figures.fig_3_2

Outputs:
    realqm/figures/output/fig_3_2.png
    realqm/figures/output/fig_3_2.log
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from realqm.parameters.constants import (
    DEFAULT_GLASS,
    C_LIGHT,
    EPSILON_0,
    Q_E,
    M_E,
)
from realqm.ensemble.ensemble import AmorphousEnsemble


# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

# The glassy disorder width
DISORDER_FRACTION = 0.15

# The frequency grid
N_POINTS = 600
OMEGA_OVER_OMEGA_0 = np.linspace(0.1, 2.0, N_POINTS)

# Homogeneous damping
GAMMA_FRACTION = 0.02


# ---------------------------------------------------------------------
# Compute the refractive index curve
# ---------------------------------------------------------------------

def compute_curve() -> dict:
    """
    Compute the refractive index n(ω) for the glassy ensemble, and
    the Sellmeier low-frequency limit.
    """
    omega_0_bar = DEFAULT_GLASS.omega_0_bar
    gamma = GAMMA_FRACTION * omega_0_bar
    N_glass = DEFAULT_GLASS.N_glass

    ens = AmorphousEnsemble(
        omega_0_bar=omega_0_bar,
        sigma_omega_0=DISORDER_FRACTION * omega_0_bar,
        gamma=gamma,
        N_glass=N_glass,
    )

    omega_grid = OMEGA_OVER_OMEGA_0 * omega_0_bar
    chi = ens.susceptibility(omega_grid)

    # n − 1 = χ c / ω
    n_minus_1 = chi * C_LIGHT / omega_grid
    n = 1.0 + n_minus_1

    # Sellmeier low-frequency limit:
    # n_sell − 1 = N q_e² ⟨1/ω₀²⟩ / (2 ε₀ m₀)
    sellmeier = (
        N_glass * Q_E**2 * ens.mean_inverse_square()
        / (2.0 * EPSILON_0 * M_E)
    )

    return {
        "x": OMEGA_OVER_OMEGA_0,
        "n_real": n.real,
        "n_imag": n.imag,
        "sellmeier": sellmeier,
        "disorder_fraction": DISORDER_FRACTION,
    }


# ---------------------------------------------------------------------
# Plot
# ---------------------------------------------------------------------

def make_figure(data: dict, output_path: Path) -> None:
    """Draw the two-panel figure and save it."""
    fig, (ax_top, ax_bottom) = plt.subplots(
        nrows=2, ncols=1, figsize=(7.0, 6.5), sharex=True,
    )

    # Top panel: Re n
    ax_top.plot(data["x"], data["n_real"],
                color="#1f4e79", linewidth=1.6, label=r"$\mathrm{Re}\,n(\omega)$")
    ax_top.axhline(
        1.0 + data["sellmeier"],
        color="#c0392b", linewidth=1.2, linestyle=":",
        label="Sellmeier limit",
    )
    ax_top.set_ylabel(r"$\mathrm{Re}\,n(\omega)$")
    ax_top.set_title("Refractive index (real part)")
    ax_top.legend(loc="upper right", fontsize=9, frameon=True)

    # Bottom panel: Im n
    ax_bottom.plot(data["x"], data["n_imag"],
                   color="#c0392b", linewidth=1.6, label=r"$\mathrm{Im}\,n(\omega)$")
    ax_bottom.axhline(0.0, color="grey", linewidth=0.5, linestyle=":")
    ax_bottom.set_ylabel(r"$\mathrm{Im}\,n(\omega)$")
    ax_bottom.set_xlabel(r"Driving frequency $\omega / \bar{\omega}_0$")
    ax_bottom.set_title("Refractive index (imaginary part)")
    ax_bottom.legend(loc="upper right", fontsize=9, frameon=True)

    fig.suptitle(
        rf"Refractive index of the amorphous lattice "
        rf"($\sigma_{{\omega_0}}/\bar{{\omega}}_0 = {DISORDER_FRACTION}$)",
        fontsize=11,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.97))

    fig.savefig(output_path, dpi=160)
    plt.close(fig)


# ---------------------------------------------------------------------
# Log
# ---------------------------------------------------------------------

def write_log(data: dict, log_path: Path) -> None:
    """Write a numerical log with the key values from the figure."""
    lines = []
    lines.append("Figure 3.2 — Refractive index of the amorphous lattice")
    lines.append("=" * 60)
    lines.append("")
    lines.append(f"Disorder: σ_ω₀/ω̄₀ = {data['disorder_fraction']}")
    lines.append(f"Homogeneous damping: γ/ω̄₀ = {GAMMA_FRACTION}")
    lines.append(f"Grid: {N_POINTS} points, "
                 f"ω/ω̄₀ ∈ [{data['x'][0]:.3f}, {data['x'][-1]:.3f}]")
    lines.append("")
    lines.append(f"Sellmeier low-frequency limit:")
    lines.append(f"  n_sell − 1 = {data['sellmeier']:.6f}")
    lines.append(f"  n_sell     = {1.0 + data['sellmeier']:.6f}")
    lines.append("")
    lines.append("At the lowest plotted frequency (ω/ω̄₀ = 0.1):")
    lines.append(f"  Re n − 1 = {data['n_real'][0] - 1.0:.6f}")
    lines.append("  (should be close to, and slightly above, the Sellmeier value)")
    lines.append("")
    lines.append("Peak of the absorption (most negative Im n):")
    idx_peak = int(np.argmin(data["n_imag"]))   # <-- argmin, not argmax
    lines.append(f"  at ω/ω̄₀ = {data['x'][idx_peak]:.4f}")
    lines.append(f"  Im n at peak = {data['n_imag'][idx_peak]:.6f}")
    lines.append(f"  |Im n| at peak = {abs(data['n_imag'][idx_peak]):.6f}")
    lines.append("")
    lines.append("Minimum of Re n (anomalous dispersion trough):")
    idx_min = int(np.argmin(data["n_real"]))
    lines.append(f"  at ω/ω̄₀ = {data['x'][idx_min]:.4f}")
    lines.append(f"  Re n at trough = {data['n_real'][idx_min]:.6f}")

    log_path.write_text("\n".join(lines), encoding="utf-8")

# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------

def main() -> None:
    output_dir = Path(__file__).parent / "output"
    output_dir.mkdir(exist_ok=True)

    data = compute_curve()
    make_figure(data, output_dir / "fig_3_2.png")
    write_log(data, output_dir / "fig_3_2.log")

    print(f"Wrote {output_dir / 'fig_3_2.png'}")
    print(f"Wrote {output_dir / 'fig_3_2.log'}")


if __name__ == "__main__":
    main()