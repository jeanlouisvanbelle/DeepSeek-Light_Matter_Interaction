"""
realqm/figures/fig_5_1.py

Figure 5.1 of the Z-2 paper: the three-channel energy ledger.

Two panels side by side:
  - Left:  pure fused silica (mu_ref = 0.1 m⁻¹)
  - Right: a scattering glass (mu_ref = 5.0 m⁻¹)

Each panel shows, as a function of path length L through the slab:
  - Fresnel reflection (solid red): R_total, the total reflected
    intensity, including multiple internal reflections.
  - First-surface Fresnel (dashed red): R_first = |r|², the
    entry-face reflection only.
  - Forward beam (blue): T_total · exp(−μ L).
  - Side-scattered (green): T_total · (1 − exp(−μ L)).
  - Total (dotted black): the sum, which is exactly 1 for every L.

The figure illustrates Z-2 Sections 5.7 and 6.5. The Fresnel
term is constant (boundary effect); the forward and side terms
exchange energy as the beam propagates (volume effect). The
first-surface Fresnel is slightly above the 4% that the paper's
simpler model predicts for n=1.5; the total includes the multiple
internal reflections, which add several percent on top.

The engine is not tuned to match the paper's 4%. The value that
comes out is what the model gives, with the default glass
parameters. The difference is a finding, not a failure.

Run from the Z-3 directory:
    python -m realqm.figures.fig_5_1

Outputs:
    realqm/figures/output/fig_5_1.png
    realqm/figures/output/fig_5_1.log
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from realqm.parameters.constants import (
    FUSED_SILICA,
    SCATTERING_GLASS,
    GREEN_PHOTON,
)
from realqm.channels.incoherent import IncoherentChannel
from realqm.slab.slab import default_slab


# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

SCENARIOS = [
    {
        "label": "Pure fused silica (μ = 0.1 m⁻¹)",
        "mu_ref": 0.1,
        "material": FUSED_SILICA,
    },
    {
        "label": "Scattering glass (μ = 5 m⁻¹)",
        "mu_ref": 5.0,
        "material": SCATTERING_GLASS,
    },
]

# Path length grid, in cm
L_CM = np.linspace(0.0, 10.0, 201)

# Colors for the channels
COLOR_FRESNEL = "#c0392b"        # total Fresnel (solid)
COLOR_FRESNEL_FIRST = "#e8a09a"  # first-surface Fresnel (dashed)
COLOR_FORWARD = "#1f4e79"
COLOR_SIDE = "#2e8b57"
COLOR_TOTAL = "black"


# ---------------------------------------------------------------------
# Compute the ledger curves
# ---------------------------------------------------------------------

def compute_panel(scenario: dict) -> dict:
    """
    Compute the three-channel ledger for one scenario, over the
    path-length grid.

    Returns a dict with the four curves (fresnel_total,
    fresnel_first, forward, side), their sum, and the diagnostic
    quantities needed for the log.
    """
    omega = GREEN_PHOTON.omega

    # Build a slab with the given mu_ref
    slab = default_slab(thickness=1.0)
    slab.incoherent = IncoherentChannel(
        N_glass=scenario["material"].N_glass,
        T_fictive=scenario["material"].T_fictive,
        K_bulk=scenario["material"].K_bulk,
        mu_ref=scenario["mu_ref"],
        lambda_ref=scenario["material"].lambda_ref,
    )

    # Complex bulk refractive index at the green photon's frequency
    n_bulk = slab.bulk_refractive_index(omega)
    n_real = n_bulk.real
    n_imag = n_bulk.imag

    # First-surface Fresnel reflectivity
    R_first = slab.fresnel_reflectivity(omega)
    T_first = 1.0 - R_first

    # Total reflected and transmitted fractions, including
    # multiple internal reflections
    denom = 1.0 - R_first * R_first
    T_total = T_first * T_first / denom
    R_total = R_first + T_first * T_first * R_first / denom

    # For comparison: the sharp-boundary reflectivity computed
    # from the real part of n alone (ignoring the imaginary part).
    R_sharp_real = ((1.0 - n_real) / (1.0 + n_real)) ** 2

    mu = slab.incoherent.extinction_coefficient(omega)

    fresnel_total = np.full_like(L_CM, R_total)
    fresnel_first = np.full_like(L_CM, R_first)
    forward = np.zeros_like(L_CM)
    side = np.zeros_like(L_CM)

    for i, L_cm in enumerate(L_CM):
        L_m = L_cm * 1e-2
        transmission = np.exp(-mu * L_m)
        forward[i] = T_total * transmission
        side[i] = T_total * (1.0 - transmission)

    total = fresnel_total + forward + side

    return {
        "label": scenario["label"],
        "L_cm": L_CM,
        "fresnel_total": fresnel_total,
        "fresnel_first": fresnel_first,
        "forward": forward,
        "side": side,
        "total": total,
        "R_total": R_total,
        "R_first": R_first,
        "T_total": T_total,
        "mu": mu,
        "n_real": n_real,
        "n_imag": n_imag,
        "R_sharp_real": R_sharp_real,
    }


# ---------------------------------------------------------------------
# Plot
# ---------------------------------------------------------------------

def make_figure(panels: list, output_path: Path) -> None:
    """Draw the two-panel figure and save it."""
    fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(11.5, 4.8),
                             sharey=True)

    for ax, panel in zip(axes, panels):
        ax.plot(panel["L_cm"], panel["fresnel_total"],
                color=COLOR_FRESNEL, linewidth=1.8,
                label="Fresnel reflection (total)")
        ax.plot(panel["L_cm"], panel["fresnel_first"],
                color=COLOR_FRESNEL_FIRST, linewidth=1.4, linestyle="--",
                label="First-surface Fresnel only")
        ax.plot(panel["L_cm"], panel["forward"],
                color=COLOR_FORWARD, linewidth=1.8,
                label="Forward beam")
        ax.plot(panel["L_cm"], panel["side"],
                color=COLOR_SIDE, linewidth=1.8,
                label="Side-scattered")
        ax.plot(panel["L_cm"], panel["total"],
                color=COLOR_TOTAL, linewidth=1.0, linestyle=":",
                label="Total (= 1)")

        ax.set_xlabel("Path length through slab (cm)")
        ax.set_title(panel["label"], fontsize=10)
        ax.set_ylim(0.0, 1.05)
        ax.grid(True, linewidth=0.3, alpha=0.5)

    axes[0].set_ylabel("Fraction of incident intensity")
    axes[0].legend(loc="center right", fontsize=8, frameon=True)

    fig.suptitle("Three-channel energy ledger", fontsize=11)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


# ---------------------------------------------------------------------
# Log
# ---------------------------------------------------------------------

def write_log(panels: list, log_path: Path) -> None:
    """Write a numerical log with the key values from the figure."""
    lines = []
    lines.append("Figure 5.1 — Three-channel energy ledger")
    lines.append("=" * 60)
    lines.append("")
    lines.append(f"Photon: {GREEN_PHOTON.energy_eV:.2f} eV "
                 f"({GREEN_PHOTON.wavelength*1e9:.0f} nm)")
    lines.append(f"Path length range: 0 to 10 cm")
    lines.append("")

    for panel in panels:
        lines.append(f"--- {panel['label']} ---")
        lines.append(f"  μ = {panel['mu']:.4f} m⁻¹")
        lines.append("")
        lines.append(f"  Complex bulk refractive index at the green photon:")
        lines.append(f"    Re n = {panel['n_real']:.6f}")
        lines.append(f"    Im n = {panel['n_imag']:.6e}")
        lines.append("")
        lines.append(f"  For comparison, the sharp-boundary reflectivity")
        lines.append(f"  computed from the real part of n alone:")
        lines.append(f"    R_sharp (real n only) = {panel['R_sharp_real']:.6f}")
        lines.append("")
        lines.append(f"  First-surface Fresnel  R_first = {panel['R_first']:.6f}")
        lines.append(f"    (includes the small contribution from Im n)")
        lines.append(f"  Total Fresnel          R_total = {panel['R_total']:.6f}")
        lines.append(f"  Multiple-reflection contribution "
                     f"= {panel['R_total'] - panel['R_first']:.6f}")
        lines.append(f"  Total transmitted      T_total = {panel['T_total']:.6f}")
        lines.append(f"  R_total + T_total = "
                     f"{panel['R_total'] + panel['T_total']:.10f}")
        lines.append("")
        lines.append(f"  At L = 0:")
        lines.append(f"    fresnel_total = {panel['fresnel_total'][0]:.6f}")
        lines.append(f"    fresnel_first = {panel['fresnel_first'][0]:.6f}")
        lines.append(f"    forward       = {panel['forward'][0]:.6f}")
        lines.append(f"    side          = {panel['side'][0]:.6f}")
        lines.append(f"    total         = {panel['total'][0]:.10f}")
        lines.append("")
        lines.append(f"  At L = 10 cm:")
        lines.append(f"    fresnel_total = {panel['fresnel_total'][-1]:.6f}")
        lines.append(f"    fresnel_first = {panel['fresnel_first'][-1]:.6f}")
        lines.append(f"    forward       = {panel['forward'][-1]:.6f}")
        lines.append(f"    side          = {panel['side'][-1]:.6f}")
        lines.append(f"    total         = {panel['total'][-1]:.10f}")
        lines.append("")

    lines.append("Notes:")
    lines.append("- The total is exactly 1 at every path length.")
    lines.append("- The Fresnel term is constant (boundary effect).")
    lines.append("- The forward and side terms exchange energy as the")
    lines.append("  beam propagates (volume effect).")
    lines.append("- The first-surface Fresnel is slightly above the 4%")
    lines.append("  that the paper's simplified model predicts for n=1.5.")
    lines.append("  The difference comes from two sources: (i) the default")
    lines.append("  glass parameters give a bulk index of about 1.373,")
    lines.append("  not 1.5; (ii) the green photon is on the low-frequency")
    lines.append("  tail of the absorption band, so Im n is small but")
    lines.append("  non-zero, and it contributes a small amount to R.")
    lines.append("- The total Fresnel includes the multiple internal")
    lines.append("  reflections, which add several percent on top of the")
    lines.append("  first-surface value.")
    lines.append("- The engine is not tuned to match the paper's 4%. The")
    lines.append("  values that come out are what the model gives with the")
    lines.append("  default glass parameters.")

    log_path.write_text("\n".join(lines), encoding="utf-8")


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------

def main() -> None:
    output_dir = Path(__file__).parent / "output"
    output_dir.mkdir(exist_ok=True)

    panels = [compute_panel(s) for s in SCENARIOS]
    make_figure(panels, output_dir / "fig_5_1.png")
    write_log(panels, output_dir / "fig_5_1.log")

    print(f"Wrote {output_dir / 'fig_5_1.png'}")
    print(f"Wrote {output_dir / 'fig_5_1.log'}")


if __name__ == "__main__":
    main()