"""
realqm/figures/fig_3_1.py

Figure 3.1 of the Z-2 paper: the ensemble-averaged susceptibility
of the amorphous lattice.

Two panels:
  - Top:    Re⟨χ(ω)⟩ vs. ω/ω̄₀
  - Bottom: Im⟨χ(ω)⟩ vs. ω/ω̄₀

Three curves per panel, for three values of the fractional disorder
σ_ω₀/ω̄₀:
  - 0.001 (crystal-like)
  - 0.05  (moderate disorder)
  - 0.15  (glassy, the default of Z-2 Section 2.3)

The figure illustrates the central claim of Z-2 Section 3.5:
disorder smooths the resonance, but the total oscillator strength
is conserved (the area under Im⟨χ⟩ is approximately the same for
all three curves).

The output subdirectory realqm/figures/output/ is created
automatically by this script. It does not need an __init__.py,
because it is a data directory, not a Python package.

Run from the Z-3/ directory:
    python -m realqm.figures.fig_3_1

Outputs:
    realqm/figures/output/fig_3_1.png
    realqm/figures/output/fig_3_1.log
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")   # headless backend, no display needed
import matplotlib.pyplot as plt
import numpy as np

from realqm.parameters.constants import DEFAULT_GLASS
from realqm.ensemble.ensemble import AmorphousEnsemble


# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

# The three disorder widths to plot
DISORDER_FRACTIONS = [0.001, 0.05, 0.15]

# Colors and labels for the three curves
CURVE_STYLE = [
    {"color": "#1f4e79", "label": r"$\sigma_{\omega_0}/\bar{\omega}_0 = 0.001$ (crystal-like)"},
    {"color": "#2e8b57", "label": r"$\sigma_{\omega_0}/\bar{\omega}_0 = 0.05$"},
    {"color": "#c0392b", "label": r"$\sigma_{\omega_0}/\bar{\omega}_0 = 0.15$ (glassy)"},
]

# The frequency grid: ω/ω̄₀ from 0.1 to 2.0
N_POINTS = 400
OMEGA_OVER_OMEGA_0 = np.linspace(0.1, 2.0, N_POINTS)

# Homogeneous damping, fixed across the three curves
GAMMA_FRACTION = 0.02   # γ / ω̄₀


# ---------------------------------------------------------------------
# Compute the susceptibility curves
# ---------------------------------------------------------------------

def compute_curves() -> dict:
    """
    Compute the ensemble-averaged susceptibility for the three
    disorder widths.

    Returns a dict with:
      - 'x': the ω/ω̄₀ grid
      - 'curves': a list of dicts, one per disorder width, each with
        keys 'disorder_fraction', 'label', 'color', 'chi_real',
        'chi_imag', and 'area_imag'.
    """
    omega_0_bar = DEFAULT_GLASS.omega_0_bar
    gamma = GAMMA_FRACTION * omega_0_bar
    N_glass = DEFAULT_GLASS.N_glass

    omega_grid = OMEGA_OVER_OMEGA_0 * omega_0_bar

    curves = []
    for frac, style in zip(DISORDER_FRACTIONS, CURVE_STYLE):
        ens = AmorphousEnsemble(
            omega_0_bar=omega_0_bar,
            sigma_omega_0=frac * omega_0_bar,
            gamma=gamma,
            N_glass=N_glass,
        )
        chi = ens.susceptibility(omega_grid)

        # Area under Im χ over the plotted range, for the
        # oscillator-strength check
        area_imag = np.trapezoid(chi.imag, omega_grid)

        curves.append({
            "disorder_fraction": frac,
            "label": style["label"],
            "color": style["color"],
            "chi_real": chi.real,
            "chi_imag": chi.imag,
            "area_imag": area_imag,
        })

    return {
        "x": OMEGA_OVER_OMEGA_0,
        "curves": curves,
    }


# ---------------------------------------------------------------------
# Plot
# ---------------------------------------------------------------------

def make_figure(data: dict, output_path: Path) -> None:
    """
    Draw the two-panel figure and save it to output_path.
    """
    fig, (ax_top, ax_bottom) = plt.subplots(
        nrows=2, ncols=1, figsize=(7.0, 6.5), sharex=True,
    )

    for curve in data["curves"]:
        ax_top.plot(data["x"], curve["chi_real"],
                    color=curve["color"], label=curve["label"],
                    linewidth=1.6)
        ax_bottom.plot(data["x"], curve["chi_imag"],
                       color=curve["color"], linewidth=1.6)

    # Top panel: Re χ
    ax_top.set_ylabel(r"$\mathrm{Re}\,\langle \chi(\omega) \rangle$")
    ax_top.axhline(0.0, color="grey", linewidth=0.5, linestyle=":")
    ax_top.legend(loc="upper right", fontsize=9, frameon=True)
    ax_top.set_title("Dispersive part")

    # Bottom panel: Im χ
    ax_bottom.set_ylabel(r"$\mathrm{Im}\,\langle \chi(\omega) \rangle$")
    ax_bottom.set_xlabel(r"Driving frequency $\omega / \bar{\omega}_0$")
    ax_bottom.axhline(0.0, color="grey", linewidth=0.5, linestyle=":")
    ax_bottom.set_title("Absorptive part")

    fig.suptitle(
        "Ensemble-averaged susceptibility of the amorphous lattice",
        fontsize=11,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.97))

    fig.savefig(output_path, dpi=160)
    plt.close(fig)


# ---------------------------------------------------------------------
# Log
# ---------------------------------------------------------------------

def write_log(data: dict, log_path: Path) -> None:
    """
    Write a numerical log with the key values from the figure.
    """
    lines = []
    lines.append("Figure 3.1 — Ensemble-averaged susceptibility")
    lines.append("=" * 60)
    lines.append("")
    lines.append(f"Grid: {N_POINTS} points, "
                 f"ω/ω̄₀ ∈ [{data['x'][0]:.3f}, {data['x'][-1]:.3f}]")
    lines.append(f"Homogeneous damping: γ/ω̄₀ = {GAMMA_FRACTION}")
    lines.append("")
    lines.append(f"{'σ_ω₀/ω̄₀':>12} "
                 f"{'max Re χ':>14} "
                 f"{'min Re χ':>14} "
                 f"{'max -Im χ':>14} "
                 f"{'∫ Im χ dω':>16}")
    lines.append("-" * 72)
    for curve in data["curves"]:
        lines.append(
            f"{curve['disorder_fraction']:>12.3f} "
            f"{curve['chi_real'].max():>14.6e} "
            f"{curve['chi_real'].min():>14.6e} "
            f"{(-curve['chi_imag']).max():>14.6e} "
            f"{curve['area_imag']:>16.6e}"
        )
    lines.append("")
    lines.append("Note: ∫ Im χ dω should be approximately equal across")
    lines.append("the three disorder widths (oscillator strength is")
    lines.append("conserved). The small differences are due to the finite")
    lines.append("integration range; the tails of the broader curves extend")
    lines.append("beyond the plotted window.")

    log_path.write_text("\n".join(lines), encoding="utf-8")


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------

def main() -> None:
    output_dir = Path(__file__).parent / "output"
    output_dir.mkdir(exist_ok=True)

    data = compute_curves()
    make_figure(data, output_dir / "fig_3_1.png")
    write_log(data, output_dir / "fig_3_1.log")

    print(f"Wrote {output_dir / 'fig_3_1.png'}")
    print(f"Wrote {output_dir / 'fig_3_1.log'}")


if __name__ == "__main__":
    main()