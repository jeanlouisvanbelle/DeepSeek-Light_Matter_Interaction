"""
realqm/figures/fig_6_2b.py

Figure 6.2b of the Z-2 paper: the Airy transmission of a coated
glass slab with a high-reflectivity surface.

The green curve is the full multiple-reflection sum T_total(L),
computed from the Airy formula with R = 0.9. The red dashed line
is the single-pass value T² = 0.01, which the Airy oscillation
does NOT average to — the fringes in this case are deep, and the
single-pass value misses the entire oscillatory structure.

Note on the illustrative R = 0.9
--------------------------------
A single air-glass interface cannot produce R = 0.9: that would
require an index contrast of n ≈ 100. A real slab with R = 0.9 is
a dielectric-coated optic (a high-reflectivity mirror stack). The
RealQM model does not, in this version, include multi-layer
coatings; the figure is therefore illustrative of the Airy
formula in the deep-fringe regime, with R = 0.9 as a
representative value. The physics of the Airy formula is the same
whatever produced the reflectivity.

Run from the Z-3 directory:
    python -m realqm.figures.fig_6_2b

Outputs:
    realqm/figures/output/fig_6_2b.png
    realqm/figures/output/fig_6_2b.log
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from realqm.parameters.constants import GREEN_PHOTON


# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

# Illustrative high reflectivity
R_COATING = 0.9
T_COATING = 1.0 - R_COATING

# Bulk refractive index for the fringe period
N_BULK = 1.441021   # value at the green photon's frequency, from the model

# Thickness range: cover about 6 fringes.
L_START_M = 1.0e-5
L_END_M   = 1.0e-5 + 1.2e-6

N_POINTS = 4000   # need a fine grid: the fringes are sharp


# ---------------------------------------------------------------------
# Compute the Airy curve
# ---------------------------------------------------------------------

def compute_curve() -> dict:
    """
    Compute the Airy transmission as a function of slab thickness,
    for an illustrative R = 0.9 coating.

    The Airy formula for a lossless slab is:

        T_total(δ) = T² / [(1 − R)² + 4R sin²(δ/2)]

    with δ = 2π n L / λ the round-trip phase.
    """
    omega = GREEN_PHOTON.omega
    lambda_ = GREEN_PHOTON.wavelength

    # Fringe period
    fringe_period = lambda_ / (2.0 * N_BULK)

    # Thickness grid
    L_m = np.linspace(L_START_M, L_END_M, N_POINTS)

    # Round-trip phase
    delta = 2.0 * np.pi * N_BULK * L_m / lambda_

    # Airy formula
    T_airy = T_COATING ** 2 / (
        (1.0 - R_COATING) ** 2
        + 4.0 * R_COATING * np.sin(delta / 2.0) ** 2
    )

    T_single = T_COATING ** 2
    T_min = T_COATING ** 2 / (1.0 + R_COATING) ** 2
    T_max = T_COATING ** 2 / (1.0 - R_COATING) ** 2
    T_avg = T_COATING ** 2 / (1.0 - R_COATING ** 2)

    return {
        "L_um": L_m * 1e6,
        "T_airy": T_airy,
        "T_single": T_single,
        "T_min": T_min,
        "T_max": T_max,
        "T_avg": T_avg,
        "R": R_COATING,
        "T": T_COATING,
        "n_bulk": N_BULK,
        "fringe_period_nm": fringe_period * 1e9,
    }


# ---------------------------------------------------------------------
# Plot
# ---------------------------------------------------------------------

def make_figure(data: dict, output_path: Path) -> None:
    """Draw the figure and save it."""
    fig, ax = plt.subplots(figsize=(9.5, 5.2))

    ax.plot(data["L_um"], data["T_airy"],
            color="#2e8b57", linewidth=1.4,
            label="Airy (full multiple-reflection sum)")
    ax.axhline(data["T_single"],
               color="#c0392b", linewidth=1.4, linestyle="--",
               label="Simple T² (no multiple reflections)")

    ax.set_xlabel("Slab thickness L (μm)")
    ax.set_ylabel("Transmitted intensity (fraction)")
    ax.set_title(
        f"Airy transmission for a high-reflectivity coating "
        f"(R = {data['R']:.1f}, "
        f"fringe period ≈ {data['fringe_period_nm']:.0f} nm)"
    )
    ax.legend(loc="center right", fontsize=9, frameon=True)
    ax.grid(True, linewidth=0.3, alpha=0.5)
    ax.set_ylim(-0.02, 1.05)

    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


# ---------------------------------------------------------------------
# Log
# ---------------------------------------------------------------------

def write_log(data: dict, log_path: Path) -> None:
    """Write a numerical log with the key values from the figure."""
    lines = []
    lines.append("Figure 6.2b — Airy transmission, high-reflectivity coating")
    lines.append("=" * 60)
    lines.append("")
    lines.append(f"Photon: {GREEN_PHOTON.energy_eV:.2f} eV "
                 f"({GREEN_PHOTON.wavelength*1e9:.0f} nm)")
    lines.append(f"Bulk refractive index (for fringe period): "
                 f"n = {data['n_bulk']:.6f}")
    lines.append(f"Illustrative coating reflectivity: R = {data['R']:.3f}")
    lines.append(f"Transmissivity: T = {data['T']:.3f}")
    lines.append(f"Fringe period: λ / (2n) = {data['fringe_period_nm']:.2f} nm")
    lines.append("")
    lines.append(f"Airy extrema:")
    lines.append(f"  T_min = T² / (1+R)² = {data['T_min']:.6f}")
    lines.append(f"  T_max = T² / (1−R)² = {data['T_max']:.6f}")
    lines.append(f"  fringe amplitude = {data['T_max'] - data['T_min']:.6f}")
    lines.append("")
    lines.append(f"Single-pass value: T² = {data['T_single']:.6f}")
    lines.append(f"Average over many fringes: T² / (1−R²) = {data['T_avg']:.6f}")
    lines.append("")
    lines.append("Notes:")
    lines.append("- For R = 0.9, the fringes sweep from T_min ≈ 0.003 to")
    lines.append("  T_max = 1.0, a fringe amplitude of ~1.0.")
    lines.append("- The single-pass value T² = 0.01 is not the average:")
    lines.append("  the average is T² / (1−R²) ≈ 0.0053, which is about")
    lines.append("  half of T². The single-pass approximation is not")
    lines.append("  merely inaccurate here; it misses the entire")
    lines.append("  oscillatory structure.")
    lines.append("- A single air-glass interface cannot produce R = 0.9;")
    lines.append("  this value is illustrative of a high-reflectivity")
    lines.append("  dielectric coating. The RealQM model does not include")
    lines.append("  multi-layer coatings in this version.")

    log_path.write_text("\n".join(lines), encoding="utf-8")


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------

def main() -> None:
    output_dir = Path(__file__).parent / "output"
    output_dir.mkdir(exist_ok=True)

    data = compute_curve()
    make_figure(data, output_dir / "fig_6_2b.png")
    write_log(data, output_dir / "fig_6_2b.log")

    print(f"Wrote {output_dir / 'fig_6_2b.png'}")
    print(f"Wrote {output_dir / 'fig_6_2b.log'}")


if __name__ == "__main__":
    main()