"""
realqm/figures/fig_5_2.py

Figure 5.2 of the Z-2 paper: the Rayleigh λ⁻⁴ scaling of the
incoherent channel.

A log-log plot of the extinction coefficient μ(λ) vs. wavelength,
for three materials:
  - Air on a clear day  (mu_ref = 1e-5 m⁻¹)
  - Fused silica        (mu_ref = 0.5  m⁻¹)
  - Heavy flint glass   (mu_ref = 25   m⁻¹)

All three curves are parallel, with slope −4 on a log-log plot.
The dashed vertical lines at 450 nm and 650 nm mark the blue and
red ends of the visible spectrum, between which the ratio of μ
is (650/450)⁴ ≈ 4.35.

Run from the Z-3/ directory:
    python -m realqm.figures.fig_5_2

Outputs:
    realqm/figures/output/fig_5_2.png
    realqm/figures/output/fig_5_2.log
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from realqm.parameters.constants import (
    AIR_CLEAR,
    FUSED_SILICA,
    HEAVY_FLINT,
)
from realqm.channels.incoherent import IncoherentChannel


# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

MATERIALS = [
    {"material": AIR_CLEAR,    "color": "#7f7f7f"},
    {"material": FUSED_SILICA, "color": "#1f4e79"},
    {"material": HEAVY_FLINT,  "color": "#c0392b"},
]

# Wavelength grid: 400 nm to 700 nm, in nm
LAMBDA_NM = np.linspace(400.0, 700.0, 301)


# ---------------------------------------------------------------------
# Compute the extinction curves
# ---------------------------------------------------------------------

def compute_curves() -> dict:
    """
    Compute the extinction coefficient for each material on the
    wavelength grid.
    """
    lambda_m = LAMBDA_NM * 1e-9   # convert nm to m

    curves = []
    for entry in MATERIALS:
        ch = IncoherentChannel.from_material(entry["material"])
        mu = np.array([ch.extinction_at_wavelength(l) for l in lambda_m])
        curves.append({
            "name": entry["material"].name,
            "color": entry["color"],
            "mu": mu,
        })

    # The blue/red ratio for the reference material (fused silica)
    ch_ref = IncoherentChannel.from_material(FUSED_SILICA)
    mu_450 = ch_ref.extinction_at_wavelength(450e-9)
    mu_650 = ch_ref.extinction_at_wavelength(650e-9)
    ratio = mu_450 / mu_650

    return {
        "lambda_nm": LAMBDA_NM,
        "curves": curves,
        "blue_red_ratio": ratio,
    }


# ---------------------------------------------------------------------
# Plot
# ---------------------------------------------------------------------

def make_figure(data: dict, output_path: Path) -> None:
    """
    Draw the log-log figure and save it to output_path.
    """
    fig, ax = plt.subplots(figsize=(7.5, 5.2))

    for curve in data["curves"]:
        ax.loglog(data["lambda_nm"], curve["mu"],
                  color=curve["color"], linewidth=1.8,
                  label=curve["name"])

    # Vertical dashed lines at the blue and red ends
    ax.axvline(450.0, color="grey", linewidth=0.7, linestyle="--")
    ax.axvline(650.0, color="grey", linewidth=0.7, linestyle="--")

    # Annotate the blue/red ratio
    ax.text(
        0.55, 0.06,
        rf"$\mu(450\,\mathrm{{nm}}) / \mu(650\,\mathrm{{nm}})"
        rf"\approx {data['blue_red_ratio']:.2f}$",
        transform=ax.transAxes,
        fontsize=10,
        color="black",
        ha="center",
        va="bottom",
        bbox=dict(boxstyle="round,pad=0.3", facecolor="white",
                  edgecolor="lightgrey"),
    )

    ax.set_xlabel(r"Wavelength $\lambda$ (nm)")
    ax.set_ylabel(r"Extinction coefficient $\mu$ (m$^{-1}$)")
    ax.set_title(r"Rayleigh $\lambda^{-4}$ scaling of the incoherent channel")
    ax.legend(loc="upper right", fontsize=9, frameon=True)
    ax.grid(True, which="both", linewidth=0.3, alpha=0.5)

    fig.tight_layout()
    fig.savefig(output_path, dpi=160)
    plt.close(fig)


# ---------------------------------------------------------------------
# Log
# ---------------------------------------------------------------------

def write_log(data: dict, log_path: Path) -> None:
    """Write a numerical log with the key values from the figure."""
    lines = []
    lines.append("Figure 5.2 — Rayleigh λ⁻⁴ scaling of the incoherent channel")
    lines.append("=" * 70)
    lines.append("")
    lines.append(f"Wavelength range: "
                 f"{data['lambda_nm'][0]:.0f} nm to {data['lambda_nm'][-1]:.0f} nm")
    lines.append("")
    lines.append(f"{'Material':<20} {'μ(450 nm)':>14} {'μ(650 nm)':>14} "
                 f"{'ratio':>10}")
    lines.append("-" * 62)
    for curve in data["curves"]:
        mu_450 = np.interp(450.0, data["lambda_nm"], curve["mu"])
        mu_650 = np.interp(650.0, data["lambda_nm"], curve["mu"])
        ratio = mu_450 / mu_650
        lines.append(
            f"{curve['name']:<20} {mu_450:>14.4e} {mu_650:>14.4e} "
            f"{ratio:>10.4f}"
        )
    lines.append("")
    lines.append(f"Universal blue/red ratio (all materials): "
                 f"{data['blue_red_ratio']:.4f}")
    lines.append(f"Expected from the λ⁻⁴ law: (650/450)⁴ = "
                 f"{(650.0/450.0)**4:.4f}")
    lines.append("")
    lines.append("Note: the three curves are parallel on this log-log")
    lines.append("plot, with slope −4. The vertical separation is set")
    lines.append("by the reference extinction coefficient of each material.")

    log_path.write_text("\n".join(lines), encoding="utf-8")


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------

def main() -> None:
    output_dir = Path(__file__).parent / "output"
    output_dir.mkdir(exist_ok=True)

    data = compute_curves()
    make_figure(data, output_dir / "fig_5_2.png")
    write_log(data, output_dir / "fig_5_2.log")

    print(f"Wrote {output_dir / 'fig_5_2.png'}")
    print(f"Wrote {output_dir / 'fig_5_2.log'}")


if __name__ == "__main__":
    main()