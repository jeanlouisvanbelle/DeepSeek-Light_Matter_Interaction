"""
realqm/function/oscillator.py

The single driven oscillator — the atomic unit of the RealQM engine.

This is the Lorentz oscillator model of Z-2 Section 2.2:

    m₀ d²x/dt² + m₀ γ dx/dt + m₀ ω₀² x = q_e E₀ e^{iωt}

with steady-state solution

    x(t) = (q_e E₀ / m₀) / [(ω₀² − ω²) + i γ ω] · e^{iωt}

The phase lag Δ of the response relative to the driving field is

    tan Δ = − γ ω / (ω₀² − ω²)

which is the physical origin of Feynman's "turn" (Z-1, Intermezzo;
Z-2, Section 2.2).

Three complex functions appear repeatedly in the engine:

  1. The bare response     R(ω) = 1 / D(ω)
     where D(ω) = (ω₀² − ω²) + i γ ω. This is the causal response
     function: its real part is exactly odd around ω₀, its imaginary
     part exactly even. This is the object that satisfies the
     Kramers-Kronig relation.

  2. The bracket           B(ω) = ω² / D(ω)
     which includes the ω² acceleration factor that enters the
     radiated field. Its symmetry is only approximate, because the
     ω² breaks the exact odd/even structure.

  3. The susceptibility    χ(ω) = (N q_e² / (2 ε₀ m₀ c ω)) · B(ω)
     which includes an additional 1/ω prefactor.

The physical displacement is proportional to R(ω). The radiated
field and the refractive index are proportional to B(ω) and χ(ω).
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from realqm.parameters.constants import Q_E, M_E


@dataclass
class DrivenOscillator:
    """
    A localized electron oscillator bound to an atomic site.

    Parameters
    ----------
    omega_0 : float
        Natural resonance frequency (rad/s).
    gamma : float
        Damping rate (rad/s).
    q_e : float
        Charge of the oscillator (C). Defaults to the elementary charge.
    m_0 : float
        Mass of the oscillator (kg). Defaults to the electron rest mass.
    """
    omega_0: float
    gamma: float
    q_e: float = Q_E
    m_0: float = M_E

    # ------------------------------------------------------------------
    # Core response functions
    # ------------------------------------------------------------------

    def denominator(self, omega: float) -> complex:
        """The complex denominator D(ω) = (ω₀² − ω²) + i γ ω."""
        return complex(self.omega_0**2 - omega**2, self.gamma * omega)

    def bare_response(self, omega: float) -> complex:
        """
        The bare response R(ω) = 1 / D(ω).

        This is the causal response function of the oscillator.
        Its real part is exactly odd around ω₀ and its imaginary part
        is exactly even. It is the object to which the Kramers-Kronig
        relation applies.

        The physical displacement is x(t) = (q_e / m₀) · R(ω) · E₀ e^{iωt}.
        """
        return 1.0 / self.denominator(omega)

    def bracket(self, omega: float) -> complex:
        """
        The bracket B(ω) = ω² / D(ω).

        This includes the ω² acceleration factor that enters the
        radiated field of a driven charge. Its real part is
        approximately odd around ω₀ and its imaginary part
        approximately even, with corrections of order γ/ω₀.
        """
        return omega**2 / self.denominator(omega)

    def response(self, omega: float) -> complex:
        """
        Steady-state displacement per unit driving field (m per V/m).

        This is (q_e / m₀) · R(ω), i.e. the complex amplitude of the
        displacement. Its magnitude peaks near ω ≈ ω₀ and its phase
        lags the drive by Δ.
        """
        return (self.q_e / self.m_0) * self.bare_response(omega)

    def phase_lag(self, omega: float) -> float:
        """
        Phase lag Δ (radians) of the displacement relative to the drive.

        Δ = arctan( − γ ω / (ω₀² − ω²) )

        Well below resonance, Δ → 0 (in phase). Well above resonance,
        Δ → −π (180° out of phase). At resonance, Δ → −π/2.
        """
        return math.atan2(-self.gamma * omega, self.omega_0**2 - omega**2)

    def susceptibility(self, omega: float, N: float) -> complex:
        """
        Complex susceptibility χ(ω) for a number density N of oscillators.

        χ(ω) = (N q_e² / (2 ε₀ m₀ c ω)) · B(ω)

        This is the quantity that enters the refractive index in
        Z-2 Section 3.4.
        """
        from realqm.parameters.constants import EPSILON_0, C_LIGHT
        prefactor = N * self.q_e**2 / (2.0 * EPSILON_0 * self.m_0 * C_LIGHT * omega)
        return prefactor * self.bracket(omega)

    def radiated_field_amplitude(self, omega: float, E_0: float) -> complex:
        """
        Complex amplitude of the forward-radiated field from a single
        oscillator driven by a field of amplitude E_0.

        The radiated field is proportional to the acceleration of the
        charge, hence to ω² x(t). The geometric factor −i⊥ (the 90°
        phase of transverse radiation) is applied by the caller, not
        here, because it depends on the direction of observation.
        """
        return omega**2 * self.response(omega) * E_0

    # ------------------------------------------------------------------
    # Diagnostics
    # ------------------------------------------------------------------

    def resonance_frequency(self) -> float:
        """
        The frequency at which the response magnitude is maximal.

        For a damped oscillator this is slightly below ω₀:

            ω_res = sqrt(ω₀² − γ²/2)

        which reduces to ω₀ in the limit γ → 0.
        """
        arg = self.omega_0**2 - 0.5 * self.gamma**2
        return math.sqrt(arg) if arg > 0.0 else 0.0

    def quality_factor(self) -> float:
        """Q = ω₀ / γ — the sharpness of the resonance."""
        return self.omega_0 / self.gamma

    def is_below_resonance(self, omega: float, tol: float = 0.1) -> bool:
        """True if ω is well below resonance (ω < (1 − tol) ω₀)."""
        return omega < (1.0 - tol) * self.omega_0


# =====================================================================
# Lineshape helpers
# =====================================================================

def lorentzian_lineshape(omega: float, omega_0: float, gamma: float) -> float:
    """
    Normalized Lorentzian absorption lineshape.

        L(ω) = (γ / π) / [(ω − ω₀)² + γ²]

    This is the imaginary part of the bare response near resonance,
    normalized so that ∫ L(ω) dω = 1.
    """
    return (gamma / math.pi) / ((omega - omega_0) ** 2 + gamma**2)