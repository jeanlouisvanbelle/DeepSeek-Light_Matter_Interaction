"""
realqm/tests/test_boundary.py

Sanity checks for the boundary region.

These tests verify:

  - the density profile goes from 0 to N_max across the boundary
  - the density gradient is concentrated at the boundary and
    integrates to the total density change
  - the Fresnel reflectivity in the sharp-boundary limit
    converges to the standard result R = (n_1 − n_2)²/(n_1 + n_2)²
  - the graded boundary reduces the reflectivity below the
    sharp-boundary value (the grading acts as an AR layer)
  - Snell's law is recovered from tangential phase continuity

A cross-check of the reflected field against the Born approximation
was attempted and removed: the Born formula as implemented had the
wrong dimensions (it gave a reflected amplitude of order k_vac
instead of order 1). The test_two_methods_agree_sharp test was
therefore removed along with it. See the module docstring of
boundary.py for details.
"""

import math
import numpy as np
import pytest

from realqm.parameters.constants import (
    DEFAULT_GLASS,
    C_LIGHT,
    REFERENCE_PHOTON,
)
from realqm.boundary.boundary import BoundaryRegion, default_boundary


@pytest.fixture
def bnd():
    """The default boundary: 1 nm transition, default glass ensemble."""
    return default_boundary(width=1.0e-9)


@pytest.fixture
def bnd_sharp():
    """A nearly-sharp boundary: 0.01 nm transition."""
    return default_boundary(width=1.0e-11)


# ---------------------------------------------------------------------
# Density profile
# ---------------------------------------------------------------------

def test_density_profile_limits(bnd):
    """N(z) → 0 in vacuum, N(z) → N_max in the bulk."""
    assert math.isclose(bnd.N_of_z(-100 * bnd.width), 0.0, abs_tol=1e-10)
    assert math.isclose(bnd.N_of_z(+100 * bnd.width), bnd.N_max, rel_tol=1e-10)


def test_density_profile_midpoint(bnd):
    """N(0) = N_max / 2 at the nominal boundary."""
    assert math.isclose(bnd.N_of_z(0.0), bnd.N_max / 2.0, rel_tol=1e-12)


def test_density_gradient_integrates_to_N_max(bnd):
    """
    ∫ (dN/dz) dz = N_max, since the profile goes from 0 to N_max.
    """
    z = np.linspace(-100 * bnd.width, 100 * bnd.width, 200_001)
    grad = bnd.density_gradient(z)
    integral = np.trapezoid(grad, z)
    assert math.isclose(integral, bnd.N_max, rel_tol=1e-3), \
        f"∫ dN/dz dz = {integral}, expected {bnd.N_max}"


# ---------------------------------------------------------------------
# Fresnel reflectivity: sharp-boundary limit
# ---------------------------------------------------------------------

def test_sharp_boundary_fresnel_limit():
    """
    As ℓ → 0, the self-consistent reflectivity converges to the
    standard Fresnel result:

        R = |(n_1 − n_2)/(n_1 + n_2)|²

    For n_1 = 1, n_2 = 1.5, this is R = 0.04, the 4% that Feynman
    set out to explain.
    """
    bnd = default_boundary(width=1e-13)   # ℓ = 0.1 pm, essentially zero
    omega = REFERENCE_PHOTON.omega

    R = bnd.reflectivity(omega, n_in=1.0)

    n_bulk = bnd.forward_index(omega)
    R_expected = abs((1.0 - n_bulk) / (1.0 + n_bulk)) ** 2

    assert math.isclose(R, R_expected, rel_tol=1e-3), \
        f"R = {R}, expected {R_expected}"


# ---------------------------------------------------------------------
# Graded boundary: reduced reflectivity
# ---------------------------------------------------------------------

def test_graded_boundary_reduces_reflectivity():
    """
    A finite-width boundary has a lower reflectivity than a sharp one,
    because the grading acts as a natural anti-reflection layer.

    This is a physical prediction of Z-2 Section 4.6.
    """
    omega = REFERENCE_PHOTON.omega

    R_sharp = default_boundary(width=1e-13).reflectivity(omega)
    R_graded = default_boundary(width=1e-9).reflectivity(omega)

    assert R_graded < R_sharp, \
        f"Graded R = {R_graded} should be < sharp R = {R_sharp}"

    # The reduction should be small for ℓ = 1 nm (ℓ k ≈ 0.05), because
    # the leading correction is (ℓ k)² / 3 ≈ 8e-4.
    relative_reduction = (R_sharp - R_graded) / R_sharp
    assert relative_reduction < 0.01, \
        f"Reduction {relative_reduction} is larger than expected"


# ---------------------------------------------------------------------
# Snell's law
# ---------------------------------------------------------------------

def test_snell_angle():
    """
    Snell's law: n_1 sin θ_1 = n_2 sin θ_2.
    """
    theta_1 = math.radians(30.0)
    n_1, n_2 = 1.0, 1.5

    theta_2 = BoundaryRegion.snell_angle(theta_1, n_1, n_2)

    # Verify the invariant
    assert math.isclose(n_1 * math.sin(theta_1), n_2 * math.sin(theta_2), rel_tol=1e-12)

    # For air-to-glass, the refracted angle should be smaller than
    # the incident angle (the beam bends toward the normal)
    assert theta_2 < theta_1, \
        f"Refracted angle {theta_2} should be < incident {theta_1}"


def test_snell_angle_normal_incidence():
    """At normal incidence, θ_1 = 0, the refracted angle is also 0."""
    theta_2 = BoundaryRegion.snell_angle(0.0, 1.0, 1.5)
    assert math.isclose(theta_2, 0.0, abs_tol=1e-12)


def test_snell_total_internal_reflection():
    """For n_1 > n_2 and sin θ_1 > n_2/n_1, total internal reflection."""
    theta_1 = math.radians(60.0)
    n_1, n_2 = 1.5, 1.0

    with pytest.raises(ValueError):
        BoundaryRegion.snell_angle(theta_1, n_1, n_2)