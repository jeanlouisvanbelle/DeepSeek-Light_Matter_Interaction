"""
realqm/tests/test_slab.py

Sanity checks for the full glass slab.

These tests verify:

  - the internal angle is given by Snell's law
  - the path length is L / cos θ₂
  - the lateral displacement is positive and grows with thickness
  - the Fresnel reflectivity in the sharp-boundary limit is ~0.04
  - the full energy ledger (including multiple reflections) closes
    for arbitrary L, μ, and incidence angle
  - R_total + T_total = 1, where R_total and T_total include all
    multiple internal reflections
  - the multiple-reflection correction is of order 3.8% for uncoated
    glass — small but not negligible
  - the transparent limit (μ L → 0) reduces to R_total + T_total = 1
  - the opaque limit (μ L → ∞) sends all transmitted light to the
    side-scattered channel
  - the Airy transmission oscillates between the expected extrema
  - the Airy average coincides with the single-pass value

The ledger tests check the *full* ledger, which includes the
multiple-reflection correction of Z-2 Section 6.5. The naive
three-term ledger R + T² + side does not close, because it omits
the light that bounces inside the slab before escaping. The
complete balance is R_total + T_total = 1, where the "total"
quantities sum the geometric series of internal bounces.
"""

import math
import numpy as np
import pytest

from realqm.parameters.constants import (
    DEFAULT_GLASS,
    C_LIGHT,
    GREEN_PHOTON,
)
from realqm.slab.slab import Slab, default_slab


@pytest.fixture
def slab():
    """A 1 cm slab of default glass, with 1 nm boundaries."""
    return default_slab(thickness=1.0e-2, boundary_width=1.0e-9)


@pytest.fixture
def slab_sharp():
    """A 1 cm slab with a nearly-sharp boundary (0.1 pm)."""
    return default_slab(thickness=1.0e-2, boundary_width=1.0e-13)


# ---------------------------------------------------------------------
# Geometry: Snell's law and path length
# ---------------------------------------------------------------------

def test_internal_angle_snell(slab):
    """The internal angle satisfies n_1 sin θ_1 = n_2 sin θ_2."""
    omega = GREEN_PHOTON.omega
    theta_1 = math.radians(30.0)
    theta_2 = slab.internal_angle(theta_1, omega)

    n_bulk = slab.bulk_refractive_index(omega).real
    assert math.isclose(math.sin(theta_1), n_bulk * math.sin(theta_2), rel_tol=1e-10)
    assert theta_2 < theta_1, "Refracted angle should be smaller than incident"


def test_internal_angle_normal_incidence(slab):
    """At normal incidence, the internal angle is 0."""
    omega = GREEN_PHOTON.omega
    theta_2 = slab.internal_angle(0.0, omega)
    assert math.isclose(theta_2, 0.0, abs_tol=1e-12)


def test_path_length_normal_incidence(slab):
    """At normal incidence, the path length is exactly the thickness."""
    omega = GREEN_PHOTON.omega
    L_path = slab.path_length(0.0, omega)
    assert math.isclose(L_path, slab.thickness, rel_tol=1e-12)


def test_path_length_grows_with_angle(slab):
    """At oblique incidence, the path length is L / cos θ₂ > L."""
    omega = GREEN_PHOTON.omega
    L_normal = slab.path_length(0.0, omega)
    L_oblique = slab.path_length(math.radians(45.0), omega)
    assert L_oblique > L_normal


def test_lateral_displacement_zero_at_normal(slab):
    """At normal incidence, the emergent beam is not displaced."""
    omega = GREEN_PHOTON.omega
    d = slab.lateral_displacement(0.0, omega)
    assert math.isclose(d, 0.0, abs_tol=1e-12)


def test_lateral_displacement_positive(slab):
    """At oblique incidence, the emergent beam is displaced."""
    omega = GREEN_PHOTON.omega
    d = slab.lateral_displacement(math.radians(45.0), omega)
    assert d > 0, "Lateral displacement should be positive"
    assert d < slab.thickness, "Displacement should be less than thickness"


def test_lateral_displacement_scales_with_thickness():
    """Doubling the thickness doubles the lateral displacement."""
    omega = GREEN_PHOTON.omega
    theta_1 = math.radians(30.0)

    slab_1 = default_slab(thickness=1.0e-2)
    slab_2 = default_slab(thickness=2.0e-2)

    d_1 = slab_1.lateral_displacement(theta_1, omega)
    d_2 = slab_2.lateral_displacement(theta_1, omega)

    assert math.isclose(d_2 / d_1, 2.0, rel_tol=1e-10)


# ---------------------------------------------------------------------
# Fresnel reflectivity
# ---------------------------------------------------------------------

def test_fresnel_reflectivity_sharp(slab_sharp):
    """
    In the sharp-boundary limit, the reflectivity is close to 0.04
    (for n_bulk ≈ 1.5).
    """
    omega = GREEN_PHOTON.omega
    R = slab_sharp.fresnel_reflectivity(omega)
    assert 0.01 < R < 0.1, f"R = {R}, expected ~0.04"


def test_fresnel_reflectivity_graded(slab, slab_sharp):
    """A graded boundary has a lower reflectivity than a sharp one."""
    omega = GREEN_PHOTON.omega
    R_graded = slab.fresnel_reflectivity(omega)
    R_sharp = slab_sharp.fresnel_reflectivity(omega)
    assert R_graded < R_sharp, \
        f"Graded R = {R_graded} should be < sharp R = {R_sharp}"


def test_fresnel_transmissivity(slab):
    """T = 1 − R."""
    omega = GREEN_PHOTON.omega
    R = slab.fresnel_reflectivity(omega)
    T = slab.fresnel_transmissivity(omega)
    assert math.isclose(R + T, 1.0, rel_tol=1e-12)


# ---------------------------------------------------------------------
# Full energy ledger (including multiple reflections)
# ---------------------------------------------------------------------

def test_ledger_closes(slab):
    """
    The full energy ledger (including multiple reflections) sums to
    I_0 for the default slab.
    """
    omega = GREEN_PHOTON.omega
    result = slab.ledger(omega, theta_1=0.0)
    assert abs(result["residual"]) < 1e-10, \
        f"Ledger residual: {result['residual']}"


def test_ledger_closes_for_various_thicknesses():
    """
    The full ledger closes for a range of thicknesses, including
    the multiple-reflection correction.
    """
    omega = GREEN_PHOTON.omega
    for L in [1e-4, 1e-3, 1e-2, 1e-1, 1.0]:
        slab = default_slab(thickness=L)
        result = slab.ledger(omega)
        assert abs(result["residual"]) < 1e-10, \
            f"Ledger residual at L = {L}: {result['residual']}"


def test_ledger_closes_for_various_angles(slab):
    """
    The full ledger closes for a range of incidence angles,
    including the multiple-reflection correction.
    """
    omega = GREEN_PHOTON.omega
    for deg in [0, 15, 30, 45, 60]:
        theta_1 = math.radians(deg)
        result = slab.ledger(omega, theta_1=theta_1)
        assert abs(result["residual"]) < 1e-10, \
            f"Ledger residual at θ_1 = {deg}°: {result['residual']}"


def test_fresnel_plus_total_transmission(slab):
    """
    R_total + T_total = 1 exactly, where R_total and T_total include
    all multiple internal reflections.
    """
    omega = GREEN_PHOTON.omega
    result = slab.ledger(omega)
    assert math.isclose(result["R_total"] + result["T_total"], 1.0, rel_tol=1e-12), \
        f"R_total + T_total = {result['R_total'] + result['T_total']}"


def test_multiple_reflection_magnitude(slab):
    """
    For uncoated glass (R ≈ 0.04), the multiple-reflection correction
    is about 3.8% of I_0 — small but not negligible.
    """
    omega = GREEN_PHOTON.omega
    result = slab.ledger(omega)
    # The multiple-reflection term should be between 1% and 10%
    assert 0.01 < result["multiple"] < 0.1, \
        f"Multiple-reflection term = {result['multiple']}"

def test_ledger_transparent_limit():
    """
    For a low-extinction slab (μ L → 0), the side-scattered fraction
    is negligible, and the ledger reduces to R_total + T_total = 1.

    We check two things:
      1. The side term is small compared to 1 (so the slab is
         transparent, as expected for low-extinction glass).
      2. The full four-term ledger (including the side term) sums
         to exactly 1.
    """
    from realqm.channels.incoherent import IncoherentChannel

    omega = GREEN_PHOTON.omega
    slab = default_slab(thickness=1e-3)   # 1 mm
    # Use a much less scattering glass: μ_ref = 1e-4 m⁻¹ instead of 0.5
    slab.incoherent = IncoherentChannel(
        N_glass=slab.incoherent.N_glass,
        T_fictive=slab.incoherent.T_fictive,
        K_bulk=slab.incoherent.K_bulk,
        mu_ref=1e-4,
        lambda_ref=slab.incoherent.lambda_ref,
    )
    result = slab.ledger(omega)

    # 1. The side term is small: the slab is transparent
    assert result["side"] < 1e-6, \
        f"Side term should be negligible, got {result['side']}"

    # 2. The full four-term ledger closes exactly
    assert math.isclose(
        result["fresnel"] + result["multiple"] + result["forward"] + result["side"],
        1.0, rel_tol=1e-12,
    )

def test_ledger_opaque_limit():
    """
    For a very thick slab (μ L → ∞), all transmitted light is
    side-scattered, and the forward term vanishes.
    """
    omega = GREEN_PHOTON.omega
    slab = default_slab(thickness=1e6)   # 1000 km
    result = slab.ledger(omega)

    # The forward term should be essentially zero
    assert result["forward"] < 1e-10, \
        f"Forward term should vanish, got {result['forward']}"
    # The side term should carry all the transmitted light,
    # including the multiple-reflection correction.
    assert math.isclose(result["side"], result["T_total"], rel_tol=1e-6), \
        f"Side {result['side']} vs T_total {result['T_total']}"


# ---------------------------------------------------------------------
# Fabry-Perot (Airy) transmission
# ---------------------------------------------------------------------

def test_airy_extrema(slab):
    """
    The Airy transmission oscillates between T²/(1+R)² and T²/(1−R)².
    """
    omega = GREEN_PHOTON.omega
    T_min, T_max = slab.airy_fringe_extrema(omega)
    assert T_max >= T_min, "T_max should be >= T_min"
    # For R = 0.04, T = 0.96: T_min ≈ 0.852, T_max ≈ 1.0
    R = slab.fresnel_reflectivity(omega)
    assert math.isclose(T_min, (1 - R)**2 / (1 + R)**2, rel_tol=1e-12)
    assert math.isclose(T_max, 1.0, rel_tol=1e-12)


def test_airy_average_coincides_with_single_pass(slab):
    """
    The average of the Airy transmission over many fringes coincides
    with the single-pass value T² to within 0.2% for uncoated glass.
    """
    omega = GREEN_PHOTON.omega
    T_avg = slab.airy_average(omega)
    R = slab.fresnel_reflectivity(omega)
    T_single = (1 - R) ** 2
    # The two should agree to within 0.2%
    assert math.isclose(T_avg, T_single, rel_tol=2e-3), \
        f"Airy average {T_avg} vs single-pass {T_single}"


def test_airy_transmission_in_range(slab):
    """
    The Airy transmission at a range of thicknesses should always
    lie between the extrema.
    """
    omega = GREEN_PHOTON.omega
    T_min, T_max = slab.airy_fringe_extrema(omega)

    # Sweep thickness over a range that covers several fringes
    # Fringe period is λ/(2n) ≈ 183 nm, so sweep over ~2 μm
    n = slab.bulk_refractive_index(omega).real
    lambda_ = 2.0 * math.pi * C_LIGHT / omega
    fringe_period = lambda_ / (2 * n)

    for L in np.linspace(1.0e-2, 1.0e-2 + 5 * fringe_period, 50):
        slab_L = default_slab(thickness=L)
        T = slab_L.airy_transmission(omega)
        assert T_min <= T <= T_max, \
            f"Airy T = {T} outside [{T_min}, {T_max}] at L = {L}"