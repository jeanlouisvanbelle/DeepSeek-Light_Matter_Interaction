"""
realqm/tests/test_oscillator.py

Sanity checks for the single driven oscillator (Z-2 Section 2.2).

These tests verify the physics of the Lorentz oscillator model:

  - the response peaks at the resonance frequency ω_res = √(ω₀² − γ²/2)
  - the phase lag has the correct limits (0 below resonance, −π/2 at
    resonance, −π above resonance)
  - the phase lag is always negative for a passive oscillator
  - the Lorentzian lineshape is correctly normalized
  - the bare response 1/D(ω) is causal (Re odd, Im even around ω₀)
  - the response has the correct physical units
  - the reference photon reproduces the numbers quoted in Z-1 and Z-2

If any of these fail, the oscillator model is wrong — do not adjust
the test to make it pass.
"""

import math
import numpy as np
import pytest

from realqm.parameters.constants import (
    DEFAULT_GLASS,
    REFERENCE_PHOTON,
    Q_E,
    M_E,
)
from realqm.function.oscillator import (
    DrivenOscillator,
    lorentzian_lineshape,
)


@pytest.fixture
def osc():
    """The default glass oscillator from Z-2 Section 2.3."""
    return DrivenOscillator(
        omega_0=DEFAULT_GLASS.omega_0_bar,
        gamma=DEFAULT_GLASS.gamma,
    )


# ---------------------------------------------------------------------
# Response magnitude and phase
# ---------------------------------------------------------------------

def test_response_peaks_at_resonance(osc):
    """The magnitude of the response is maximal at ω_res."""
    omega_res = osc.resonance_frequency()
    grid = np.linspace(0.5e16, 1.5e16, 2001)
    mags = np.abs([osc.response(w) for w in grid])
    omega_at_peak = grid[int(np.argmax(mags))]
    assert math.isclose(omega_at_peak, omega_res, rel_tol=1e-2), \
        f"peak at {omega_at_peak:.3e}, expected {omega_res:.3e}"


def test_phase_lag_limits(osc):
    """Phase lag: 0 below resonance, −π/2 at resonance, −π above."""
    assert math.isclose(osc.phase_lag(0.01 * osc.omega_0), 0.0, abs_tol=1e-2)
    assert math.isclose(osc.phase_lag(osc.omega_0), -math.pi / 2, abs_tol=1e-6)
    assert math.isclose(osc.phase_lag(100 * osc.omega_0), -math.pi, abs_tol=1e-2)


def test_phase_lag_is_negative(osc):
    """For a passive oscillator, the response always lags the drive."""
    for w in np.linspace(1e14, 1e17, 1001):
        assert osc.phase_lag(w) <= 0.0, f"positive lag at ω={w:.3e}"


# ---------------------------------------------------------------------
# Lineshape and causality
# ---------------------------------------------------------------------

def test_lorentzian_normalization():
    """
    ∫ L(ω) dω = 1 for the Lorentzian lineshape.

    The integration window must be wide enough that the tails
    contribute less than the tolerance. At ±1000γ, the missing tail
    is 2·arctan(1/1000)/π ≈ 6.4e-4, which is within the 1e-3
    tolerance.
    """
    omega_0, gamma = 1.0e16, 1.0e14
    omega = np.linspace(
        omega_0 - 1000 * gamma,
        omega_0 + 1000 * gamma,
        2_000_001,
    )
    L = np.array([lorentzian_lineshape(w, omega_0, gamma) for w in omega])
    integral = np.trapezoid(L, omega)
    assert math.isclose(integral, 1.0, rel_tol=1e-3), f"integral = {integral}"

def test_phase_lag_low_frequency(osc):
    """
    Low-frequency limit of the phase lag: Δ ≈ −γω/ω₀² for ω ≪ ω₀.

    This is the regime of visible light in glass, where the driving
    frequency is far below the UV resonance. The phase lag is the
    physical origin of Feynman's "turn" (Z-1 Intermezzo, Z-2 Section
    2.2), and its low-frequency scaling is what produces the
    refractive index in the visible.
    """
    omega_0 = osc.omega_0
    gamma = osc.gamma

    # Frequencies well below resonance
    omegas = np.array([0.001, 0.002, 0.005, 0.01, 0.02]) * omega_0

    for w in omegas:
        delta = osc.phase_lag(w)
        expected = -gamma * w / omega_0**2
        assert math.isclose(delta, expected, rel_tol=1e-3), \
            f"phase lag at ω={w:.3e}: {delta:.3e} vs {expected:.3e}"


def test_phase_lag_scales_linearly(osc):
    """
    The phase lag is linear in ω at low frequency.

    This is the regime that matters for the refractive index of glass
    in the visible: the phase lag is the source of the phase shift
    that produces n(ω) − 1, and its linearity in ω at low frequency
    is what makes the refractive index approximately constant across
    the visible band.
    """
    omega_0 = osc.omega_0

    omegas = np.array([0.001, 0.002, 0.005, 0.01, 0.02]) * omega_0
    deltas = np.array([osc.phase_lag(w) for w in omegas])

    # Fit log|Δ| vs log ω; the slope should be 1 (linear).
    log_w = np.log(omegas)
    log_d = np.log(np.abs(deltas))
    slope = np.polyfit(log_w, log_d, 1)[0]
    assert 0.99 < slope < 1.01, \
        f"phase lag is not linear in ω at low frequency: slope={slope}"

# ---------------------------------------------------------------------
# Units and reference numbers
# ---------------------------------------------------------------------

def test_units_of_response(osc):
    """The response has units of m per (V/m), i.e. m²/V."""
    omega = 0.01 * osc.omega_0
    x_over_E = abs(osc.response(omega))
    expected = Q_E / (M_E * osc.omega_0**2)
    assert math.isclose(x_over_E, expected, rel_tol=1e-2), \
        f"{x_over_E:.3e} vs {expected:.3e}"


def test_reference_photon_numbers():
    """The reference photon reproduces the numbers quoted in Z-1/Z-2."""
    p = REFERENCE_PHOTON
    assert math.isclose(p.energy_J, 10.2 * 1.602176634e-19, rel_tol=1e-12)
    assert math.isclose(p.omega, 1.55e16, rel_tol=2e-2)
    assert math.isclose(p.wavelength * 1e9, 122.0, rel_tol=2e-2)
    assert math.isclose(p.E_field / 1e6, 83.3, rel_tol=2e-2)
    assert math.isclose(p.F_electric / 1e-11, 1.33, rel_tol=2e-2)
    assert math.isclose(p.B_field, 0.278, rel_tol=2e-2)
    assert math.isclose(p.F_magnetic / 1e-14, 9.74, rel_tol=5e-2)