"""
realqm/tests/test_ensemble.py

Sanity checks for the amorphous ensemble.

These tests verify:

  - the Gaussian distribution is correctly normalized
  - the vectorised production path agrees with an independent
    fine-grid reference, including near resonance
  - the adaptive quad cross-check is approximately correct
    (within its inherent accuracy on a sharp resonance)
  - the crystal limit (σ_ω₀ → 0) recovers the single-oscillator response
  - the Sellmeier limit (ω → 0) recovers the low-frequency refractive
    index, including the disorder correction to ⟨1/ω₀²⟩
  - the naive Sellmeier form is recovered as σ_ω₀ → 0
  - broadening conserves oscillator strength

If any of these fail, the ensemble model is wrong — do not adjust
the test to make it pass.
"""

import math
import numpy as np
import pytest

from realqm.parameters.constants import (
    DEFAULT_GLASS,
    C_LIGHT,
    EPSILON_0,
    Q_E,
    M_E,
)
from realqm.ensemble.ensemble import AmorphousEnsemble, default_ensemble
from realqm.function.oscillator import DrivenOscillator


@pytest.fixture
def ens():
    """The default glass ensemble from Z-2 Section 2.3."""
    return default_ensemble()


@pytest.fixture
def osc():
    """The default glass oscillator (for comparison)."""
    return DrivenOscillator(
        omega_0=DEFAULT_GLASS.omega_0_bar,
        gamma=DEFAULT_GLASS.gamma,
    )


# ---------------------------------------------------------------------
# Distribution
# ---------------------------------------------------------------------

def test_distribution_normalization(ens):
    """∫ P(ω₀) dω₀ = 1 (up to the truncation at 0)."""
    omega_0 = np.linspace(
        ens.omega_0_bar - 20 * ens.sigma_omega_0,
        ens.omega_0_bar + 20 * ens.sigma_omega_0,
        200_001,
    )
    P = ens.P(omega_0)
    integral = np.trapezoid(P, omega_0)
    # The truncated Gaussian integrates to 1 - erfc(ω̄₀/(√2 σ)) / 2,
    # which for ω̄₀/σ ≈ 6.7 is 1 - 1e-11. So 1e-4 tolerance is fine.
    assert math.isclose(integral, 1.0, rel_tol=1e-4), f"integral = {integral}"


def test_distribution_mean_and_width(ens):
    """The first and second moments match ω̄₀ and σ_ω₀."""
    omega_0 = np.linspace(
        ens.omega_0_bar - 20 * ens.sigma_omega_0,
        ens.omega_0_bar + 20 * ens.sigma_omega_0,
        200_001,
    )
    P = ens.P(omega_0)
    mean = np.trapezoid(omega_0 * P, omega_0)
    var = np.trapezoid((omega_0 - mean) ** 2 * P, omega_0)
    assert math.isclose(mean, ens.omega_0_bar, rel_tol=1e-4)
    assert math.isclose(math.sqrt(var), ens.sigma_omega_0, rel_tol=1e-3)


# ---------------------------------------------------------------------
# Two-method cross-check
# ---------------------------------------------------------------------

def test_average_methods_agree(ens):
    """
    The vectorised production path must agree with an independent
    fine-grid reference.

    Two independent methods are compared:
      - vec:  vectorised production path, uniform grid spacing γ/50
      - ref:  fine-grid trapezoidal reference, 10⁶ points

    These should agree to the level of the production grid's
    quadrature error (~1%).

    A third method, adaptive quad with a break point at ω₀ = ω, is
    available as average_scalar; it is checked separately in
    test_scalar_average_is_approximately_correct, at its own
    (looser) accuracy.
    """
    def f(omega, omega_0):
        return 1.0 / ((omega_0**2 - omega**2) + 1j * ens.gamma * omega)

    omegas = np.array([0.5, 0.9, 0.99, 1.0, 1.01, 1.1, 1.5]) * ens.omega_0_bar

    vec = ens.average(omegas, f)
    ref = np.array([ens.average_fine(w, f, n_points=1_000_000) for w in omegas])

    np.testing.assert_allclose(
        vec, ref, rtol=1e-2,
        err_msg="Vectorised path does not match fine-grid reference",
    )


def test_scalar_average_is_approximately_correct(ens):
    """
    The adaptive quad cross-check should be approximately correct
    (within ~10%), even if it is less accurate than the fine grid
    on a sharp resonance.

    This is a sanity check on the quad path, not a high-accuracy
    verification. Adaptive quadrature is excellent for smooth
    integrands but can be less accurate than a dense uniform grid
    when the integrand has a sharp resonance.
    """
    def f(omega, omega_0):
        return 1.0 / ((omega_0**2 - omega**2) + 1j * ens.gamma * omega)

    omegas = np.array([0.9, 1.0, 1.1]) * ens.omega_0_bar
    quad = np.array([ens.average_scalar(w, f) for w in omegas])
    ref = np.array([ens.average_fine(w, f, n_points=1_000_000) for w in omegas])

    np.testing.assert_allclose(
        quad, ref, rtol=0.1,
        err_msg="Scalar quad average is far from the fine-grid reference",
    )


# ---------------------------------------------------------------------
# Crystal limit
# ---------------------------------------------------------------------

def test_crystal_limit(osc):
    """
    As σ_ω₀ → 0, the ensemble average converges to the single-oscillator
    response.
    """
    ens = AmorphousEnsemble(
        omega_0_bar=osc.omega_0,
        sigma_omega_0=1e-3 * osc.omega_0,
        gamma=osc.gamma,
        N_glass=DEFAULT_GLASS.N_glass,
    )

    def f(omega, omega_0):
        D = (omega_0**2 - omega**2) + 1j * ens.gamma * omega
        return omega**2 / D

    omegas = np.array([0.99, 0.999, 1.0, 1.001, 1.01]) * osc.omega_0
    avg = ens.average(omegas, f)
    single = np.array([osc.bracket(w) for w in omegas])

    np.testing.assert_allclose(
        avg, single, rtol=0.05,
        err_msg="Crystal limit does not recover single-oscillator response",
    )


# ---------------------------------------------------------------------
# Sellmeier limit
# ---------------------------------------------------------------------

def test_sellmeier_limit(ens):
    """
    As ω → 0, the ensemble-averaged susceptibility approaches the
    low-frequency form

        ⟨χ(ω)⟩ ≈ (N q_e² / (2 ε₀ m₀ c ω)) · ω² ⟨1/ω₀²⟩

    so that n − 1 = ⟨χ⟩ c / ω is

        n − 1 ≈ N q_e² ⟨1/ω₀²⟩ / (2 ε₀ m₀)

    The ensemble average ⟨1/ω₀²⟩ differs from 1/ω̄₀² by the disorder
    correction.
    """
    omegas = np.array([1e-4, 2e-4, 5e-4, 1e-3]) * ens.omega_0_bar

    chi = ens.susceptibility(omegas)
    n_minus_1 = chi * C_LIGHT / omegas

    sellmeier = (
        ens.N_glass * Q_E**2 * ens.mean_inverse_square() / (2.0 * EPSILON_0 * M_E)
    )

    np.testing.assert_allclose(
        n_minus_1.real, sellmeier, rtol=2e-2,
        err_msg="Sellmeier limit does not match the ensemble-averaged form",
    )
    spread = (n_minus_1.real.max() - n_minus_1.real.min()) / n_minus_1.real.mean()
    assert spread < 1e-3, f"n − 1 varies by {spread} across the low-frequency range"


def test_sellmeier_naive_limit():
    """
    As σ_ω₀ → 0, the ensemble-averaged Sellmeier value converges to
    the naive 1/ω̄₀² form.
    """
    ens = AmorphousEnsemble(
        omega_0_bar=DEFAULT_GLASS.omega_0_bar,
        sigma_omega_0=1e-4 * DEFAULT_GLASS.omega_0_bar,
        gamma=DEFAULT_GLASS.gamma,
        N_glass=DEFAULT_GLASS.N_glass,
    )

    naive = (
        ens.N_glass * Q_E**2 / (2.0 * EPSILON_0 * M_E * ens.omega_0_bar**2)
    )
    corrected = (
        ens.N_glass * Q_E**2 * ens.mean_inverse_square() / (2.0 * EPSILON_0 * M_E)
    )

    assert math.isclose(corrected, naive, rel_tol=1e-6), \
        f"naive = {naive}, corrected = {corrected}"


# ---------------------------------------------------------------------
# Broadening conserves oscillator strength
# ---------------------------------------------------------------------

def test_broadening_conserves_area():
    """
    Increasing σ_ω₀ broadens the absorption peak but does not change
    its total area (the oscillator strength is conserved).
    """
    widths = [0.001, 0.05, 0.15]
    areas = []

    omega = np.linspace(0.5e16, 1.5e16, 20001)

    for frac in widths:
        ens = AmorphousEnsemble(
            omega_0_bar=DEFAULT_GLASS.omega_0_bar,
            sigma_omega_0=frac * DEFAULT_GLASS.omega_0_bar,
            gamma=DEFAULT_GLASS.gamma,
            N_glass=DEFAULT_GLASS.N_glass,
        )
        B = ens.bracket(omega)
        area = np.trapezoid(-B.imag, omega)
        areas.append(area)

    areas = np.array(areas)
    spread = (areas.max() - areas.min()) / areas.mean()
    assert spread < 0.05, f"Oscillator strength varies by {spread}"