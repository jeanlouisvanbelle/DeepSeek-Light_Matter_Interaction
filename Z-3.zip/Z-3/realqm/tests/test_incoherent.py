"""
realqm/tests/test_incoherent.py

Sanity checks for the incoherent side-scattering channel.

These tests verify:

  - the fractional variance of density fluctuations is small (~1%)
  - the Rayleigh λ⁻⁴ scaling is exact
  - the ratio μ(450)/μ(650) matches the value quoted in Z-2 Figure 5.2
    (approximately 4.35)
  - the Beer-Lambert attenuation is positive and monotonic
  - the side-scattered fraction is small for optically thin samples
    and approaches 1 for optically thick samples

The tests use a *visible* photon (550 nm, the photopic reference),
not the 10.2 eV Lyman-α photon used for the oscillator calculations.
The visible photon is the one that makes the beam visible in the
glass slab of Z-2's Figure 1.

The tests check the *scaling* of μ with λ, not its absolute value.
The absolute value depends on the prefactor (the full Rayleigh
cross-section), which is deferred to a future paper.
"""

import math
import numpy as np
import pytest

from realqm.parameters.constants import (
    C_LIGHT,
    GREEN_PHOTON,
    REFERENCE_PHOTON,
)
from realqm.channels.incoherent import (
    IncoherentChannel,
    default_incoherent_channel,
    LAMBDA_REF,
    K_B,
    K_GLASS,
)


@pytest.fixture
def ch():
    """The default incoherent channel."""
    return default_incoherent_channel()


# ---------------------------------------------------------------------
# Density fluctuations
# ---------------------------------------------------------------------

def test_fractional_variance_is_small(ch):
    """
    The fractional variance of the density fluctuations should be
    small (~1%), which is why glass is transparent.
    """
    frac = ch.fractional_variance()
    assert 0.001 < frac < 0.05, \
        f"Fractional variance {frac} is outside the expected range"


def test_fractional_variance_scales_with_T_f():
    """
    Doubling the fictive temperature doubles the fractional variance.
    """
    ch1 = IncoherentChannel(N_glass=2.2e28, T_fictive=800.0)
    ch2 = IncoherentChannel(N_glass=2.2e28, T_fictive=1600.0)
    assert math.isclose(ch2.fractional_variance(),
                        2.0 * ch1.fractional_variance(),
                        rel_tol=1e-12)


# ---------------------------------------------------------------------
# Rayleigh λ⁻⁴ scaling
# ---------------------------------------------------------------------

def test_rayleigh_lambda_minus_4(ch):
    """
    The extinction coefficient scales exactly as λ⁻⁴.
    """
    lambda_1 = 400e-9
    lambda_2 = 800e-9
    mu_1 = ch.extinction_at_wavelength(lambda_1)
    mu_2 = ch.extinction_at_wavelength(lambda_2)
    assert math.isclose(mu_1 / mu_2, 16.0, rel_tol=1e-12), \
        f"μ(400)/μ(800) = {mu_1/mu_2}, expected 16"


def test_blue_red_ratio(ch):
    """
    The ratio μ(450)/μ(650) should be (650/450)⁴ ≈ 4.35.

    This is the number quoted in Figure 5.2 of Z-2.
    """
    mu_450 = ch.extinction_at_wavelength(450e-9)
    mu_650 = ch.extinction_at_wavelength(650e-9)
    ratio = mu_450 / mu_650
    expected = (650.0 / 450.0) ** 4
    assert math.isclose(ratio, expected, rel_tol=1e-12)
    assert math.isclose(ratio, 4.35, rel_tol=1e-2), \
        f"μ(450)/μ(650) = {ratio}, expected ~4.35"


def test_rayleigh_factor_at_reference(ch):
    """At the reference wavelength, the Rayleigh factor is exactly 1."""
    omega_ref = 2.0 * math.pi * C_LIGHT / ch.lambda_ref
    assert math.isclose(ch.rayleigh_factor(omega_ref), 1.0, rel_tol=1e-12)


# ---------------------------------------------------------------------
# Beer-Lambert
# ---------------------------------------------------------------------

def test_beer_lambert_at_zero_path(ch):
    """I(0) = I_0."""
    I_0 = 1.0
    omega = GREEN_PHOTON.omega
    assert math.isclose(ch.beer_lambert(I_0, 0.0, omega), I_0, rel_tol=1e-12)


def test_beer_lambert_monotonic(ch):
    """The attenuated intensity decreases monotonically with L."""
    I_0 = 1.0
    omega = GREEN_PHOTON.omega
    L_values = np.linspace(0, 10.0, 100)
    intensities = np.array([ch.beer_lambert(I_0, L, omega) for L in L_values])
    assert np.all(np.diff(intensities) <= 0), \
        "Beer-Lambert intensity is not monotonically decreasing"


def test_beer_lambert_optically_thin(ch):
    """
    For μ L ≪ 1, the attenuation is approximately linear:

        I(L) ≈ I_0 (1 − μ L)

    We use a visible photon (550 nm), where μ = 0.5 m⁻¹. Over
    L = 1 mm, μ L = 5e-4, so the linear approximation is good to
    better than 1e-6.
    """
    I_0 = 1.0
    omega = GREEN_PHOTON.omega
    L = 1e-3   # 1 mm
    I_L = ch.beer_lambert(I_0, L, omega)
    mu = ch.extinction_coefficient(omega)
    expected = I_0 * (1.0 - mu * L)
    assert math.isclose(I_L, expected, rel_tol=1e-5), \
        f"I(L) = {I_L}, 1 − μL = {expected}"


# ---------------------------------------------------------------------
# Side-scattered fraction
# ---------------------------------------------------------------------

def test_side_scattered_fraction_at_zero_path(ch):
    """At L = 0, no light has been scattered."""
    omega = GREEN_PHOTON.omega
    assert math.isclose(ch.side_scattered_fraction(0.0, omega), 0.0, abs_tol=1e-15)


def test_side_scattered_fraction_approaches_one(ch):
    """
    For μ L ≫ 1, essentially all light is scattered.
    """
    omega = GREEN_PHOTON.omega
    L = 1e6   # 1000 km, μ L = 5e5
    frac = ch.side_scattered_fraction(L, omega)
    assert math.isclose(frac, 1.0, abs_tol=1e-10)


def test_side_scattered_fraction_visible(ch):
    """
    For a 1 cm slab of optical glass and a visible photon, the
    side-scattered fraction should be in the range that is visible
    to the eye (roughly 1e-3 to 1e-2).

    The human eye can detect a beam when about 1e-3 to 1e-4 of the
    photons are scattered into the line of sight. For μ = 0.5 m⁻¹
    and L = 1 cm, μ L = 5e-3, so the scattered fraction is 0.5%,
    comfortably in the visible range.
    """
    omega = GREEN_PHOTON.omega
    L = 0.01   # 1 cm
    frac = ch.side_scattered_fraction(L, omega)
    assert frac > 1e-3, f"Side-scattered fraction {frac} is too small to be visible"
    assert frac < 0.05, f"Side-scattered fraction {frac} is too large for transparent glass"


def test_uv_photon_is_strongly_scattered(ch):
    """
    A 10.2 eV photon (122 nm, deep UV) has a Rayleigh factor of about
    (550/122)⁴ ≈ 410, so over 1 cm the extinction μ L is of order 2,
    and the scattered fraction is large. This is a check that the
    Rayleigh scaling is doing its job: UV light is strongly scattered
    compared to visible light.
    """
    omega = REFERENCE_PHOTON.omega
    L = 0.01   # 1 cm
    frac = ch.side_scattered_fraction(L, omega)
    assert frac > 0.5, f"UV photon should be strongly scattered, got frac = {frac}"


def test_beer_lambert_plus_side_scattered_conserves_energy(ch):
    """
    For a pure scattering medium (no absorption), the forward
    intensity plus the side-scattered intensity equals the incident
    intensity.
    """
    I_0 = 1.0
    omega = GREEN_PHOTON.omega
    L = 0.1
    I_forward = ch.beer_lambert(I_0, L, omega)
    I_side = I_0 * ch.side_scattered_fraction(L, omega)
    assert math.isclose(I_forward + I_side, I_0, rel_tol=1e-12), \
        f"Energy not conserved: forward + side = {I_forward + I_side}"