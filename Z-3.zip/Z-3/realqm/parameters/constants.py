"""
realqm/parameters/constants.py

Physical constants and default material parameters for the RealQM
engine.

This file is the single source of truth for every numerical value
used in the engine. Every number quoted in the Z-1 and Z-2 papers,
and every number that will appear in the Z-3 write-up, should trace
back to a named symbol here. If a future figure disagrees with the
paper, the discrepancy is resolved by comparing against this file.

The engine models the interaction of a localized photon wavepacket
with a localized electron oscillator in an amorphous ensemble. Three
things are needed to specify a physical situation:

  1. The photon: its energy (in eV), from which its frequency,
     wavelength, field strength, and the force it exerts on a
     stationary electron are derived.

  2. The glass: its microstructure (lattice spacing, mean resonance
     frequency, inhomogeneous width, damping, number density) and
     its macroscopic targets (refractive index, Fresnel reflectivity,
     extinction coefficient). The microstructure parameters are the
     inputs; the macroscopic targets are what the model is expected
     to reproduce.

  3. The boundary: the finite-width transition region between air
     and glass, of characteristic width ℓ.

  4. The scattering material: for the incoherent channel, a material
     is specified by its number density, fictive temperature, bulk
     modulus, and reference extinction coefficient.

All quantities are in SI units unless otherwise stated. Energies
are quoted in electron-volts (eV) for readability, since this is
the traditional unit in atomic physics; the conversion to joules is
exact and is done automatically by the ReferencePhoton class. Since
the 2019 revision of the SI, the conversion factor is exact.

Naming conventions
------------------
- REFERENCE_PHOTON : the 10.2 eV Lyman-α photon of hydrogen. This is
  the running example in Z-1 and Z-2 for the *oscillator* physics.
  It is ultraviolet, not visible to the human eye, but it is
  readily detectable by a standard photosensor. It is NOT the
  photon that produces the visible track in the glass slab of Z-2
  Figure 1.
- GREEN_PHOTON : a 2.25 eV photon at 550 nm. This is the photopic
  reference (green, peak of human visual sensitivity). It is used
  in the incoherent-scattering calculations, where the visible
  wavelength is what matters. It is NOT the only visible photon;
  it is one specific visible photon, chosen because 550 nm is the
  standard reference for μ values.
- DEFAULT_GLASS : a set of microstructure parameters for a generic
  optical glass (crown-like), and the associated macroscopic
  targets. These are approximate defaults; the model is not tuned
  to match a specific commercial glass.
- AIR_CLEAR, FUSED_SILICA, HEAVY_FLINT : three ScatteringMaterial
  instances used for the incoherent channel, in particular for
  Figure 5.2 (the Rayleigh λ⁻⁴ scaling).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field


# =====================================================================
# 1. Fundamental constants (SI, CODATA 2018)
# =====================================================================
# These are the physical constants that appear in the equations of
# the engine. They are quoted from the CODATA 2018 recommended
# values; the 2019 SI revision made several of them exact by
# definition (c, h, e, k_B).

C_LIGHT: float = 2.99792458e8          # speed of light in vacuum (m/s)
H_PLANCK: float = 6.62607015e-34       # Planck constant (J·s)
HBAR: float = H_PLANCK / (2.0 * math.pi)  # reduced Planck constant (J·s)
Q_E: float = 1.602176634e-19           # elementary charge (C)
M_E: float = 9.1093837015e-31          # electron rest mass (kg)
EPSILON_0: float = 8.8541878128e-12    # vacuum permittivity (F/m)
MU_0: float = 1.25663706212e-6         # vacuum permeability (H/m)
ALPHA: float = 7.2973525693e-3         # fine-structure constant (dimensionless)
E_V: float = 1.602176634e-19           # 1 eV in joules (J)
K_B: float = 1.380649e-23              # Boltzmann constant (J/K)

# Derived
ALPHA_C: float = ALPHA * C_LIGHT       # αc ≈ 2.19e6 m/s (orbital electron velocity scale)


# =====================================================================
# 2. Named photons
# =====================================================================
# Two photons appear repeatedly in the RealQM papers and in this engine.
# They play different roles and should not be confused.

@dataclass(frozen=True)
class ReferencePhoton:
    """
    A photon of a given energy, with its derived quantities.

    Parameters
    ----------
    energy_eV : float
        Photon energy in electron-volts.

    Derived attributes
    ------------------
    energy_J : float
        Photon energy in joules.
    omega : float
        Angular frequency (rad/s), from E = ℏω.
    wavelength : float
        Wavelength (m) in vacuum, from λ = hc/E.
    period : float
        Period (s), from T = h/E.
    E_field : float
        Peak electric field (V/m), from E_λ = q_e E λ.
    F_electric : float
        Force on a stationary electron (N), from F = q_e E.
    B_field : float
        Peak magnetic field (T), from B = E/c.
    F_magnetic : float
        Magnetic force at v = αc (N), from F = q_e αc B.
    """
    energy_eV: float = 10.2
    energy_J: float = field(init=False)
    omega: float = field(init=False)
    wavelength: float = field(init=False)
    period: float = field(init=False)
    E_field: float = field(init=False)
    F_electric: float = field(init=False)
    B_field: float = field(init=False)
    F_magnetic: float = field(init=False)

    def __post_init__(self) -> None:
        E_J = self.energy_eV * E_V
        object.__setattr__(self, "energy_J", E_J)
        object.__setattr__(self, "omega", E_J / HBAR)
        object.__setattr__(self, "wavelength", H_PLANCK * C_LIGHT / E_J)
        object.__setattr__(self, "period", H_PLANCK / E_J)
        E_field = E_J / (Q_E * self.wavelength)
        object.__setattr__(self, "E_field", E_field)
        object.__setattr__(self, "F_electric", Q_E * E_field)
        B_field = E_field / C_LIGHT
        object.__setattr__(self, "B_field", B_field)
        object.__setattr__(self, "F_magnetic", Q_E * ALPHA_C * B_field)


# The 10.2 eV Lyman-α photon of hydrogen (n=2 → n=1 transition).
REFERENCE_PHOTON = ReferencePhoton(energy_eV=10.2)
# Expected values:
#   omega      ≈ 1.55e16 rad/s
#   wavelength ≈ 122 nm (deep UV)
#   E_field    ≈ 83.3 MV/m
#   F_electric ≈ 1.33e-11 N
#   B_field    ≈ 0.278 T
#   F_magnetic ≈ 9.74e-14 N

# A 2.25 eV photon at 550 nm (green, photopic reference).
GREEN_PHOTON = ReferencePhoton(energy_eV=2.25)
# Expected values:
#   omega      ≈ 3.42e15 rad/s
#   wavelength ≈ 550 nm
#   E_field    ≈ 6.8 MV/m
#   F_electric ≈ 1.1e-12 N
#   B_field    ≈ 0.023 T


# =====================================================================
# 3. Default glass parameters
# =====================================================================
# From Z-2 Section 2.3: lattice spacing, mean resonance frequency,
# inhomogeneous width, damping, and the resulting macroscopic optical
# constants.

@dataclass
class GlassParameters:
    """
    Default parameters for a generic optical glass (crown-like).

    The microstructure parameters are the inputs. The macroscopic
    targets are what the model should reproduce with realistic
    inputs. The engine does not tune the inputs to match the
    targets; it takes the inputs as given and computes the
    macroscopic optical properties.
    """
    # --- Microstructure (inputs) ---
    lattice_spacing: float = 0.4e-9        # ~0.4 nm between SiO₂ tetrahedra
    omega_0_bar: float = 1.0e16            # mean resonance frequency (rad/s)
    sigma_omega_0: float = 1.5e15          # inhomogeneous width (rad/s)
    gamma: float = 1.0e14                  # damping rate (rad/s)
    N_glass: float = 2.2e28                # number density of oscillators (m^-3)

    # --- Macroscopic optical targets (outputs the model should approach) ---
    n_glass: float = 1.5                   # refractive index in the visible
    R_fresnel: float = 0.04                # normal-incidence reflectivity
    mu_glass: float = 0.5                  # extinction coefficient (m^-1)

    # --- Boundary ---
    boundary_width: float = 1.0e-9         # ℓ ≈ 1 nm (polished surface)

    def fractional_disorder(self) -> float:
        """
        σ_ω₀ / ω̄₀ — the dimensionless disorder parameter.
        """
        return self.sigma_omega_0 / self.omega_0_bar


DEFAULT_GLASS = GlassParameters()


# =====================================================================
# 4. Scattering materials (for the incoherent channel)
# =====================================================================
# A ScatteringMaterial is a set of parameters for the IncoherentChannel
# class: the number density of scatterers, the fictive temperature, the
# bulk modulus, and the reference extinction coefficient at a reference
# wavelength. Three named materials are provided, for use in Figure 5.2
# (the Rayleigh λ⁻⁴ scaling).

@dataclass(frozen=True)
class ScatteringMaterial:
    """
    A material for the incoherent (Rayleigh) scattering channel.

    Parameters
    ----------
    name : str
        Human-readable name, for figures and logs.
    N_glass : float
        Number density of scattering centers (m⁻³).
    T_fictive : float
        Fictive temperature (K). For amorphous solids, the
        temperature at which the structure froze in. For gases,
        this is not physically meaningful; the value is set to
        room temperature and the scattering is instead controlled
        by mu_ref directly.
    K_bulk : float
        Bulk modulus (Pa). For amorphous solids, this sets the
        energy cost of a density fluctuation. For gases, it is
        not physically meaningful.
    mu_ref : float
        Extinction coefficient at lambda_ref (m⁻¹).
    lambda_ref : float
        Reference wavelength (m). Default 550 nm.
    """
    name: str
    N_glass: float
    T_fictive: float
    K_bulk: float
    mu_ref: float
    lambda_ref: float = 550e-9


# Air on a clear day. The scattering is from molecular density
# fluctuations in the atmosphere, not from frozen-in disorder, so
# T_fictive and K_bulk are placeholders. The reference extinction
# coefficient is taken from the visible-range empirical value.
AIR_CLEAR = ScatteringMaterial(
    name="Air (clear day)",
    N_glass=2.5e25,
    T_fictive=300.0,
    K_bulk=1.0e5,
    mu_ref=1.0e-5,
)

# Fused silica (pure SiO₂ glass). The reference values are the
# defaults used in the incoherent channel tests.
FUSED_SILICA = ScatteringMaterial(
    name="Fused silica",
    N_glass=2.2e28,
    T_fictive=1500.0,
    K_bulk=3.7e10,
    mu_ref=0.5,
)

# Heavy flint glass. Higher density of scatterers and a higher
# fictive temperature, giving a much larger extinction coefficient.
HEAVY_FLINT = ScatteringMaterial(
    name="Heavy flint glass",
    N_glass=2.2e28,
    T_fictive=800.0,
    K_bulk=3.7e10,
    mu_ref=25.0,
)

# A generic scattering glass, used in Figure 5.1's right panel to
# show the opaque limit of the ledger. The reference extinction
# coefficient is 5 m⁻¹, ten times larger than fused silica, which
# corresponds to a glass with a much higher density of frozen-in
# fluctuations (e.g. a rapidly quenched sample, or a glass with a
# higher fictive temperature).
SCATTERING_GLASS = ScatteringMaterial(
    name="Scattering glass",
    N_glass=2.2e28,
    T_fictive=1200.0,
    K_bulk=3.7e10,
    mu_ref=5.0,
)

# =====================================================================
# 5. Convenience: unit conversions
# =====================================================================
# Since the 2019 SI revision, the electron-volt is defined exactly in
# terms of the joule (1 eV = 1.602176634e-19 J, exact).

def eV_to_J(E_eV: float) -> float:
    """Convert energy from electron-volts to joules."""
    return E_eV * E_V


def J_to_eV(E_J: float) -> float:
    """Convert energy from joules to electron-volts."""
    return E_J / E_V


def omega_to_lambda(omega: float) -> float:
    """Convert angular frequency (rad/s) to wavelength (m) in vacuum."""
    return 2.0 * math.pi * C_LIGHT / omega


def lambda_to_omega(lam: float) -> float:
    """Convert wavelength (m) in vacuum to angular frequency (rad/s)."""
    return 2.0 * math.pi * C_LIGHT / lam